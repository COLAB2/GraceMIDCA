# cc -fPIC -shared -o fun.so SRC/Actuators.c
import ctypes
import serial
from ctypes.util import find_library

class GraceFun():
    def __init__(self):
        self.func = ctypes.CDLL("GliderFun.so")
        self.func.initIPC.argtypes=None
        self.func.initIPC.restype = ctypes.c_int
        self.socket = self.func.initIPC()

    def sendXbeeMsg(self, msg):
        try:
           x= serial.Serial(port="/dev/ttyS0",baudrate=9600,parity=serial.PARITY_NONE,stopbits=serial.STOPBITS_ONE,bytesize=serial.EIGHTBITS)
           return 0<x.write(msg+"\r\n")
        except:
           return False

    def moveMass(self,pos):
        func = self.func
        func.moveMass.argtypes=[ctypes.c_double]
        func.moveMass(float(pos))

    def moveServo(self,pos):
        func = self.func
        func.moveServo.argtypes=[ctypes.c_int]
        func.moveServo(int(pos))
	
    def oscillateServo(self,bias, amp, time_float):
        func = self.func
        func.oscillateServo.argtypes=[ctypes.c_double,ctypes.c_double,ctypes.c_float]
        func.oscillateServo(bias, amp, time_float)

    def movePump(self,pos):
        func = self.func
        func.movePump.argtypes=[ctypes.c_double]
        func.movePump(float(pos))
    
    def setThrusterSpeed(self,spd):
        func = self.func
        func.setPropellerSpeed.argtypes=[ctypes.c_int]
        func.setPropellerSpeed(int(spd))

    def readMassPercentage(self):
        func = self.func
        func.readMassPercentage.restype = ctypes.c_float
        func.readMassPercentage.argtypes=None
        return func.readMassPercentage()
   
    def readMassPos(self):
        func = self.func
        func.readMassPos.restype = ctypes.c_float
        func.readMassPos.argtypes=None
        return func.readMassPos()
 
    def readMassVoltage(self):
        func = self.func
        func.readMassVoltage.restype = ctypes.c_float
        func.readMassVoltage.argtypes=None
        return func.readMassVoltage()

    def readPumpPercentage(self):
        func.readPumpPercentage.restype = ctypes.c_float
        func.readPumpPercentage.argtypes=None
        return func.readPumpPercentage()

    def readPumpPos(self):
        func = self.func
        func.readPumpPos.restype = ctypes.c_float
        func.readPumpPos.argtypes=None
        return func.readPumpPos()
 
    def readPumpVoltage(self):
        func = self.func
        func.readPumpVoltage.restype = ctypes.c_float
        func.readPumpVoltage.argtypes=None
        return func.readPumpVoltage()
       
    def readServoAngle(self):
        func = self.func
        func.readServoAngle.restype = ctypes.c_float
        func.readServoAngle.argtypes=None
        return func.readServoAngle()

    def readRawPressure(self):
        func = self.func
        func.readPressure.restype = ctypes.c_float
        func.readPressure.argtypes=None
        return func.readPressure()
    
    def readPressure(self):
        func = self.func
        func.readFilteredPressure.restype = ctypes.c_float
        func.readFilteredPressure.argtypes=None
        return func.readFilteredPressure()
    
    def readSurfacePressure(self):
        func = self.func
        func.readSurfacePressure.restype = ctypes.c_float
        func.readSurfacePressure.argtypes=None
        return func.readSurfacePressure()
 
    def pressureToDepth(self,press):
        func = self.func
        func.pressureToDepth.restype = ctypes.c_float
        func.pressureToDepth.argtypes=[ctypes.c_float]
        return func.pressureToDepth(press)
        
    def readDepth(self):
        func = self.func
        return self.pressureToDepth(self.readPressure())
    
    def calibrateSurfacePressure(self,samples):
        func = self.func
        func.calibrateSurfacePressure.restype = ctypes.c_float
        func.calibrateSurfacePressure.argtypes=[ctypes.c_int]
        return self.pressureToDepth(int(samples))

    def readBattery(self):
        func = self.func
        func.readBattery.restype = ctypes.c_float
        func.readBattery.argtypes=None
        return func.readBattery()
    
    def readInTemp(self):
        func = self.func
        func.readInTemp.restype = ctypes.c_int
        func.readInTemp.argtypes=None
        return func.readInTemp()
    
    def readDOCON(self):
        func = self.func
        func.readDOCON.restype = ctypes.c_float
        func.readDOCON.argtypes=None
        return func.readDOCON()   

    def readDOTEMP(self):
        func = self.func
        func.readDOTEMP.restype = ctypes.c_float
        func.readDOTEMP.argtypes=None
        return func.readDOTEMP() 
    
    def readDOPPS(self):
        func = self.func
        func.readDOPPS.restype = ctypes.c_float
        func.readDOPPS.argtypes=None
        return func.readDOPPS() 

    def readDOSAT(self):
        func = self.func
        func.readDOSAT.restype = ctypes.c_float
        func.readDOSAT.argtypes=None
        return func.readDOSAT() 

    def readPar(self):
        func = self.func
        func.readPar.restype = ctypes.c_float
        func.readPar.argtypes=None
        return func.readPar() 

    def readAlgaeCy(self):
        func = self.func
        func.readAlgaeCy.restype = ctypes.c_float
        func.readAlgaeCy.argtypes=None
        return func.readAlgaeCy()

    def readChlorophylCy(self):
        func = self.func
        func.readChlorophylCy.restype = ctypes.c_float
        func.readChlorophylCy.argtypes=None
        return func.readChlorophylCy()

    def readIMUTemperature(self):
        func = self.func
        func.readIMUTemperature.restype = ctypes.c_float
        func.readIMUTemperature.argtypes=None
        return func.readIMUTemperature()
    
    def readIMUPressure(self):
        func = self.func
        func.readIMUPressure.restype = ctypes.c_float
        func.readIMUPressure.argtypes=None
        return func.readIMUPressure()

    def readAccelX(self):
        func = self.func
        func.readAccelX.restype = ctypes.c_float
        func.readAccelX.argtypes=None
        return func.readAccelX()
    
    def readAccelY(self):
        func = self.func
        func.readAccelY.restype = ctypes.c_float
        func.readAccelY.argtypes=None
        return func.readAcceYZ()
    
    def readAccelZ(self):
        func = self.func
        func.readAccelZ.restype = ctypes.c_float
        func.readAccelZ.argtypes=None
        return func.readAccelZ()
    
    def readRollRate(self):
        func = self.func
        func.readRollRate.restype = ctypes.c_float
        func.readRollRate.argtypes=None
        return func.readRollRate()

    def readPitchRate(self):
        func = self.func
        func.readPitchRate.restype = ctypes.c_float
        func.readPitchRate.argtypes=None
        return func.readPitchRate()
    
    def readYawRate(self):
        func = self.func
        func.readYawRate.restype = ctypes.c_float
        func.readYawRate.argtypes=None
        return func.readYawRate()
    
    def readRoll(self):
        func = self.func
        func.readRoll.restype = ctypes.c_float
        func.readRoll.argtypes=None
        return func.readRoll()

    def readPitch(self):
        func = self.func
        func.readPitch.restype = ctypes.c_float
        func.readPitch.argtypes=None
        return func.readPitch()
    
    def readYaw(self):
        func = self.func
        func.readYaw.restype = ctypes.c_float
        func.readYaw.argtypes=None
        return func.readYaw()

    def readLattitude(self):
        func = self.func
        func.readLattitude.restype = ctypes.c_float
        func.readLattitude.argtypes=None
        return func.readLattitude()

    def readLongitude(self):
        func = self.func
        func.readLongitude.restype = ctypes.c_float
        func.readLongitude.argtypes=None
        return func.readLongitude()
    
    def readGPSTime(self):
        func = self.func
        func.readGPSTime.restype = ctypes.c_long
        func.readGPSTime.argtypes=None
        return func.readGPSTime()
 
    def readLongFlag(self):
        func = self.func
        func.readLongFlag.restype = ctypes.c_char
        func.readLongFlag.argtypes=None
        return func.readLongFlag()  
       
    def readLatFlag(self):
        func = self.func
        func.readLatFlag.restype = ctypes.c_char
        func.readLatFlag.argtypes=None
        return func.readLatFlag()    

    def readGPSValid(self):
        func = self.func
        func.readGPSValid.restype = ctypes.c_char
        func.readGPSValid.argtypes=None
        return func.readGPSValid() 

    def GPS_GetDistanceToTarget(self,targetLat, targetLong):
        func = self.func
        func.GPS_GetDistanceToTarget.restype = ctypes.c_char
        func.GPS_GetDistanceToTarget.argtypes=[ctypes.c_float,ctypes.c_float]
        func.GPS_GetDistanceToTarget(targetLat, targetLong)
    
    def GPS_GetBearingToTarget(self,targetLat, targetLong):
        func = self.func
        func.GPS_GetBearingToTarget.restype = ctypes.c_char
        func.GPS_GetBearingToTarget.argtypes=[ctypes.c_float,ctypes.c_float]
        func.GPS_GetBearingToTarget(targetLat, targetLong)
