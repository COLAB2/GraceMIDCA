from goprocam import GoProCamera,constants
import sys

command =""
try:
    command = sys.argv[1]
except:
    pass
print(command)
gpc=GoProCamera.GoPro()
if command == 'video':
    gpc.shoot_video( )
else:
    gpc.shutter(constants.stop)
        
        
