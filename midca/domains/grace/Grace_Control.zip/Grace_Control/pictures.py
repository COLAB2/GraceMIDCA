import sys
from goprocam import GoProCamera,constants

interval = 1
num = 1
name = "snap"
for i in range(len(sys.argv)):
    if sys.argv[i][0]=='-':
        if sys.argv[i] == "-interval":
            interval = int(sys.argv[i+1])
        elif sys.argv[i] == "-num":
            num = int(sys.argv[i+1])
        elif sys.argv[i] == "-name":
            name = sys.argv[i+1]

gpc= GoProCamera.GoPro()

for i in range(num):
     gpc.downloadLastMedia(gpc.take_photo(interval),"DATALOG/"+name+str(i))

            
        
