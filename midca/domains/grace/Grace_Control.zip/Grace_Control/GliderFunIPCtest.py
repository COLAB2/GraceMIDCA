# cc -fPIC -shared -o fun.so SRC/Actuators.c
import ctypes
from ctypes.util import find_library

func = ctypes.CDLL("GliderFun.so")
func.initIPC.argtypes=None
func.initIPC()

func.moveMass.argtypes=[ctypes.c_float]
func.moveMass(5)
func.moveServo.argtypes=[ctypes.c_int]
func.moveServo(0)
func.readMassPercentage.restype = ctypes.c_float
func.readMassPercentage.argtypes=None
print func.readMassPercentage()
