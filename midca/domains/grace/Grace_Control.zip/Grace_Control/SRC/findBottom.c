#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include <math.h>
#include <time.h>
#include "GliderFunIPC.h"
#define sgn(v) ((v<0)?-1:(v>0))

float pitch;
float surfacePressure = 0;
float saturationPressure = 3.28;
float COB;
float COM;



int main(int argc, char **argv){
	if (initIPC()<=0){
		printf("Could not connect to dataPipe.c\n");
		exit(-1);
	}
	logProgramStart(argc,argv);
	//surfacePressure = calibrateSurfacePressure(10);
	surfacePressure = readSurfacePressure();
	printf("Avg. surface depth = %f\n", pressureToDepth(surfacePressure));
	
	float depth = 0;
	float interval = 30;
	float massF = 50.0;
	float massB = 50.0;
	float depthTop = pressureToDepth(surfacePressure) + pressureOffset;
	
	COM = 50;
	COB = 50;
	for (int i = 0;i<argc;i++){
			if(argv[i][0]=='-'){
				if(strcmp(argv[i]+1,"COB")==0)
					COB = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"COM")==0)
					COM = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"DT")==0)
					depthTop = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"interval")==0)
					interval = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"MassF")==0)
					massF = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"MassB")==0)
					massB = atof(argv[i+1]);	
			}
	}
	
	if (depthTop < pressureToDepth(surfacePressure) + 0.03) {
		printf("Specified top depth is less than computed surface depth.\n");
		exit(-1);
	}
	if (interval<5)
		interval=5;
	printf("find bottom interval: -%f\n",interval);
	movePump(3);
	FILE *fp;
	fp = fopen("atBottom", "w");
	fprintf(fp,"0");
	fclose(fp);
	//sleep(30);
	float currentDepth=pressureToDepth(readFilteredPressure());
	time_t start = time(NULL);
	while(difftime(time(NULL),start) < interval){
		sleep(5);
		currentDepth = pressureToDepth(readFilteredPressure());
		if (depth < currentDepth){
			depth = currentDepth;
			start = time(NULL);
		}
	}
	fp = fopen("atBottom", "w");
	fprintf(fp,"1");
	fclose(fp);	
	movePump(99.0);
	//while (currentDepth > depthTop) {
	//	currentDepth = pressureToDepth(readFilteredPressure());
	//}
}
