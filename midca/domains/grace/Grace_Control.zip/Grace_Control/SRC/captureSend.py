from goprocam import GoProCamera,constants
import time

video = constants.Mode.VideoMode
multishot = constants.Mode.MultiShotMode
timelapse = constants.Mode.SubMode.MultiShot.TimeLapse
gpc = GoProCamera.GoPro()
var = "0"
while(var!="7"):
    var=input("1 to record video, 2 to record timelapse, or 7 to stop: ")
    if(var == "1"):
        gpc.shoot_video()
    if(var == "2"):
        gpc.mode(video,timelapse)
        print(gpc.getMedia())
        gpc.shutter(constants.start)
    if(var == "3"):
        gpc.mode(multishot,timelapse)
        print(gpc.getMedia())
        gpc.shutter(constants.start)
    if(var=="4"):
        gpc.shutter(constants.stop)
        
    if(var=="5"):
        print(gpc.downloadLastMedia())
    if(var=="6"):
        print(gpc.getMedia())
        
        
        
