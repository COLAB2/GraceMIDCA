#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include <math.h>
#include <time.h>
#include <sys/time.h> //FD_SET, FD_ISSET, FD_ZERO macros 
#include "GliderFunIPC.h"

float pitch;
float surfacePressure = 0;
float saturationPressure = 3.28;
float COB;
float COM;

//~ float pressureToDepth(double pressure){
	 //~ return (pressure-.521131)/(0.04) * 0.7038;
 //~ }
 
//~ void calibrateSurfacePressure() {
	//~ int samples = 10;
	//~ surfacePressure = 0;
	//~ for (int i = 0; i < samples; i++) {
		//~ usleep(10000);
		//~ surfacePressure += readFilteredPressure();
	//~ }
	//~ surfacePressure /= samples;
//~ }

void singleDive(double targetDepth, double massForward, double massBackward){
	moveMass(massForward);
	usleep(300000);
	movePump(0.01);
	//float currentPressure = readFilteredPressure();
	usleep(300000);
	float currentDepth = pressureToDepth(readFilteredPressure());
	while(currentDepth<=targetDepth){
		currentDepth = pressureToDepth(readFilteredPressure());		
		usleep(300000);
		//printf("%f\n",currentDepth);
	}
	movePump(99.9);
	usleep(30000);
	moveMass(massBackward);
}

void singleDivePID(double targetDepth, double massForward, double massBackward,struct PID* pid){
	struct timeval update,start;
	gettimeofday(&start, NULL);
	moveMass(massForward);
	usleep(300000);
	//movePump(0.01);
	//float currentPressure = readFilteredPressure();
	usleep(300000);
	float currentDepth = pressureToDepth(readFilteredPressure());
	while(currentDepth<=targetDepth){
		gettimeofday(&update, NULL);
		pid->dt = (float)(update.tv_sec-start.tv_sec)+(float)(update.tv_usec-start.tv_usec)/1e6f;
		currentDepth = pressureToDepth(readFilteredPressure());	
		float newPos = COB + PIDcalculation(currentDepth-targetDepth,pid);
		printf("newPos = %f\n",newPos);
		movePump(saturate(newPos,0.05,99.9));
		gettimeofday(&start, NULL);
		usleep(300000);
		printf("%f\n",currentDepth);
	}
	movePump(99.9);
	usleep(30000);
	moveMass(massBackward);
}

int main(int argc, char **argv){
	if (initIPC()<=0){
		printf("Could not connect to dataPipe.c\n");
		exit(-1);
	}
	logProgramStart(argc,argv);
	//surfacePressure = calibrateSurfacePressure(10);
	surfacePressure = readSurfacePressure();
	printf("Avg. surface depth = %f\n", pressureToDepth(surfacePressure));
	struct PID pid;
	pid.Kp = 13;
	pid.Ki = 5;
	pid.Kd = 0;
	pid.satFlag = 1;
	pid.highSat = 1;
	pid.lowSat = -1;
	float depth = 0;
	float massF = 50.0;
	float massB = 50.0;
	float depthTop = pressureToDepth(surfacePressure) + pressureOffset;
	
	int n = 1;
	COM = 50;
	COB = 50;
	for (int i = 0;i<argc;i++){
			if(argv[i][0]=='-'){
				if(strcmp(argv[i]+1,"COB")==0)
					COB = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"COM")==0)
					COM = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"D")==0)
					depth = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"DT")==0)
					depthTop = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"MassF")==0)
					massF = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"MassB")==0)
					massB = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"n")==0)
					n = atoi(argv[i+1]);
				else if(strcmp(argv[i]+1,"kp")==0)
					pid.Kp = atof(argv[i+1]);	
				else if(strcmp(argv[i]+1,"kd")==0)
					pid.Kd = atof(argv[i+1]);	
				else if(strcmp(argv[i]+1,"ki")==0)
					pid.Ki = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"PIDSatFlag")==0)
					pid.satFlag = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"PIDHighSat")==0)
					pid.highSat = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"PIDLowSat")==0)
					pid.lowSat = atof(argv[i+1]);

			}
	}
	
	if (depthTop < pressureToDepth(surfacePressure)) {
		printf("Specified top depth (%f) is less than computed surface depth.\n",depthTop);
		exit(-1);
	}
	
	printf("dive params: \n \tCOB-%f\n \tCOM-%f\n \tDepth-%f\n \tDepth top-%f\n \tMF-%f\n \tMB-%f\n \tn-%d\n",COB,COM,depth,depthTop,massF,massB,n);
	
	
	//singleDive(depthToPressure(depth),massF,massB);
	for (int i = 0; i < n; i++) {
		printf("Dive %d of %d\n",i+1,n);
		singleDivePID((double)depth,(double)massF,(double)massB,&pid);
		usleep(30000);

		float currentDepth=pressureToDepth(readFilteredPressure());
		printf("current depth = %f\n",currentDepth);
		while (currentDepth > depthTop) {
			usleep(300000);
			currentDepth = pressureToDepth(readFilteredPressure());
			printf("current depth = %f\n",currentDepth);
		}
	}
}
