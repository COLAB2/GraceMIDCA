/*  GliderDefinitions.h
 *  This program contains important shared data such as robot actuation 
 *  limits and definitions of where variables are stored in microcontrollers.
 *  Also contains helpful shared finctions that do not require mcu interaction.
 * */
 #pragma once
#ifndef _GDEFS
#define _GDEFS
//macros
#define sgn(v) ((v<0)?-1:(v>0))
//OPTS_NO_FORMAT
// constants
#define MAX_ANALOG_VOLATAGE 3.3 
float pump_remap_constant=0.67;
const int SERVO_MAX_ANGLE = 60;
const int SERVO_MIN_ANGLE = -60;
const float pressureOffset = 0.38;
#define SERVER_NAME "SAMA"
#define MAIN_MCU_TAG "MAIN"
#define SENSOR_MCU_TAG "SENSOR"
#define BATT_MON_TAG "BATTERY"
#define PROPELLER_MCU_TAG "PROPELLER"
#define ACOUSTIC_RECIEVER_MCU_TAG "ACOUSTIC"
#define RPI_TAG "RASP_PI"
											
const int mmcu_varnum = 26;
const int misc_varnum = 2;
const int emcu_varnum=7;

const int SURFACE_PRESSURE = 1; //rpi reads

const char SERVO_READ = (char)0, //send to Main MCU to read
	 MASS_READ = (char)1,
	 PUMP_READ = (char)2,
	 PRESSURE_READ = (char)3,
	 PRESSURE_AVG_READ = (char)4,
	 PRESSURE_BWF_READ = (char)5,
	 GPS_TIME_READ = (char)6,
	 GPS_DATE_READ = (char)7,
	 GPS_LAT_READ = (char)8,
	 GPS_NS_FLAG_READ = (char)9,
	 GPS_LONG_READ = (char)10,
	 GPS_EW_FLAG_READ = (char)11,
	 GPS_VALID_READ = (char)12,
	 IMU_YAW_READ =(char)13,
	 IMU_PITCH_READ = (char)14,
	 IMU_ROLL_READ = (char)15,
	 IMU_YAW_RATE_READ = (char)16,
	 IMU_PITCH_RATE_READ = (char)17,
	 IMU_ROLL_RATE_READ = (char)18,
	 IMU_ACCEL_X_READ = (char)19,
	 IMU_ACCEL_Y_READ = (char)20,
	 IMU_ACCEL_Z_READ = (char)21,
	 IMU_Temperature_READ = (char)22,
	 IMU_PRESSURE_READ = (char)23,
	 TimeStartUp_READ = (char)24,
	 TimeSyncIn_READ = (char)25;
	 
const char STOP_MASS = (char)26,
     STOP_PUMP = (char)27,
	 STOP_SERVO = (char)28,
	 IMU_TARE = (char)29,
	 IMU_HEADING_MODE = (char)30,
	 IMU_SAVE = (char)31;
	 
	 
const char DO_CONC_READ = (char)0, //send to Sensor MCU to read
	 DO_TEMP_READ = (char)1,
	 DO_PAR_PRESS_READ = (char)2,
	 DO_SAT_READ = (char)3,
	 CYC1_READ = (char)4,
	 CYC2_READ = (char)5,
	 PAR_READ = (char)6;
 
const char BATT_READ = (char)0, //send to Sensor MCU to read
	       BATT_TEMP_READ = (char)1;
	       
const char  ACOUSTIC_READ = 'R',
			ACOUSTIC_SYNC_TIME = 'D';      

const int READ_FLOAT = 4,
		  READ_LONG = 4,
		  READ_CHAR = 1;

//variables
float _COM = 40;
float massActLen;
float _COB = 50;
float pumpActLen;
int waitTime = 10000;//microseconds


 //Structs
struct PID{
   float Kp;
   float Ki;
   float Kd;
   float lastError;
   float totalError;
   float highSat;
   float lowSat;
   float dt;
   int satFlag;
}; 
//END_OPTS
float ToDegrees(float radians);
float ToRadians(float degrees);
float PIDcalculation(float error,struct PID* pid);  
float saturate(float val, float minVal, float maxVal);
 
void calibrate();
void setWaitTime();
float getCOM(){return _COM;};
float getCOB(){return _COB;};




 //Misc Functions  
float PIDcalculation(float error,struct PID* pid){
	float eChange = (error - pid->lastError)/pid->dt;
	pid->totalError+= (error*pid->dt);
	if(pid->satFlag==1)
		pid->totalError=saturate(pid->totalError,pid->lowSat,pid->highSat);
	pid->lastError = error;
	return pid->Kp*error+pid->Ki*pid->totalError+pid->Kd*eChange;
};
float ToRadians(float degrees){
	return degrees*M_PI/180.0f;
};

float ToDegrees(float radians){
	return radians*180.0/M_PI;
};

//setup system calibration
void calibrate(){
	char* cobPath = "Calibration/COB.txt";
	char* comPath = "Calibration/COM.txt";
	char* convertPath = "Calibration/conversionData.txt";
};

void setWaitTime(int t_usec){
	waitTime = t_usec;
}

float saturate(float val, float minVal, float maxVal){
	float min=(val>maxVal)?maxVal:val;//min
	return (min>minVal)?min:minVal;//max
};	
float min(float val1, float val2){
	return (val1>val2)?val2:val1;//min
};
float max(float val1, float val2){
	return (val1<val2)?val2:val1;//max
};
#endif
