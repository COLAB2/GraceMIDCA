#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include "GliderDefinitions.h"
//char *srv ="./socket1";
char *srv ="SAMA";
int sock, rc;
//char *srv ="./socket" ;

void sendReadMeassage(char* mcu, char varToRead){
	char msg[50]={0};
	sprintf(msg,"R,%s,%c",mcu,varToRead);
	printf("%s\n",msg);
	send(sock,msg,strlen(msg),0);
	
}

float readBatt(){
	sendReadMeassage("BATTERY",PRESSURE_READ);
	float voltage;
	rc = read(sock,&voltage,sizeof(voltage));
	if (rc<0){
		perror("write");
	}
	return voltage;
}
int main(){
	struct sockaddr_un addr;
	char buff[1024];
	int sock, rc;
	sock = socket(AF_UNIX,SOCK_STREAM,0);
	if(sock < 0){
		perror("socket error");
		exit(-1);
	}
	//memset(&addr,0,sizeof(struct sockaddr_un));
	memset(&addr,0,sizeof(addr));
	addr.sun_family = AF_UNIX;
	//strncpy(addr.sun_path,srv,sizeof(addr.sun_path)-1);
	//strcpy(addr.sun_path,srv);
	if (*srv == '\0'){
		printf("-%c-",*srv);
		*addr.sun_path = '\0';
		strncpy(addr.sun_path+1,srv+1,sizeof(addr.sun_path)-2);
	}
	else{
		printf("-%c-+122\n",*srv);
		addr.sun_path[0]=0;
		strcpy(addr.sun_path+1,srv);
		printf("%s\n",addr.sun_path);
	}
	
	//if(connect(sock,(struct sockaddr *) &addr,sizeof(struct sockaddr_un))<0){
	int len =sizeof(struct sockaddr_un)+strlen(srv)+1;
	len =sizeof(sa_family_t)+strlen(srv)+1;
	printf("%d ",len);
	if(connect(sock,(struct sockaddr *) &addr, len)<0){
		close(sock);
		perror("connection error");
	}  
	else{
		const int mmcu_varnum = 26;
		const int misc_varnum = 2;
		const int emcu_varnum=7;
		printf("connection successful\n\n");
		int kill = 0;
		struct timeval to;
		to.tv_sec = 1;
		to.tv_usec = 0;
		setsockopt(sock,SOL_SOCKET,SO_RCVTIMEO,(const char*)&to,sizeof(to));
		int state = 0;
		while(kill!=1){
			memset(buff,0,sizeof(buff));
			scanf("%s",buff);
			if(strcmp(buff,"exit")==0||strcmp(buff,"kill")==0){
				kill=1;
			}
			char s[100]= {0};
			int i = atoi(buff);
			float fl_var;
			long lng_var;
			char chr_var;
			if(i<mmcu_varnum){
				sprintf(s,"R,MAIN,%d,-s",i);
				//sprintf(s,"R,MAIN,%d",i);
			}
			if (i >= mmcu_varnum){
				sprintf(s,"R,SENSOR,%d,-s",i%mmcu_varnum);
				//sprintf(s,"R,SENSOR,%d",i%mmcu_varnum);
			}
			if (i >= mmcu_varnum+emcu_varnum){
				sprintf(s,"R,BATTERY,%d,-s",i%(mmcu_varnum+emcu_varnum));
				//sprintf(s,"R,BATTERY,%d",i%(mmcu_varnum+emcu_varnum));
			}
			send(sock,s,strlen(s),0);
			printf("sent: %s\n",s);
			memset(buff,0,sizeof(buff));
			if ( i<0){
				state=(1+state)%4;
			}
			if(state == 0){
				read(sock,buff,sizeof(buff));
				printf("recieved string: %s\n",buff);
			}
			if(state == 1){
				read(sock,buff,sizeof(fl_var));
				memcpy(&fl_var,buff,sizeof(buff));
				printf("recieved float: %f\n",fl_var);
			}
			if(state == 2){
				read(sock,&lng_var,sizeof(lng_var));
				printf("recieved long: %lu\n",lng_var);
			}
			if(state == 3){
				read(sock,&chr_var,sizeof(chr_var));
				printf("recieved char: %c\n",chr_var);
			}
			//printf("%f",readBatt());

		}
	} 
}
