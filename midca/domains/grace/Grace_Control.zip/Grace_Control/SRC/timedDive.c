
#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include <time.h>
#include <math.h>
#include "GliderFunIPC.h"

float pitch;
float saturationPressure = 3.28;

void singleDive(double diveTime,double massForward, double massBackward){
	moveMass(massForward);
	usleep(2*100000);
	movePump(0.01);
	time_t start = time(NULL);
	while(difftime(time(NULL),start) < diveTime){sleep((int)(diveTime*.1));
		//printf("%f\n",difftime(time(NULL),start));
	}
	movePump(99.0);
	usleep(2*100000);
	moveMass(massBackward);
}
int main(int argc, char **argv){
	if (initIPC()<0){
		printf("Could not connect to dataPipe.c\n");
		exit(-1);
	}
	logProgramStart(argc,argv);
	float Timer = 30;
	float massF = 50.0;
	float massB = 50.0;
	int n = 1;
	for (int i = 0;i<argc;i++){
			if(argv[i][0]=='-'){
				if(strcmp(argv[i]+1,"D")==0)
					Timer = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"MassF")==0)
					massF = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"MassB")==0)
					massB = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"n")==0)
					n = atoi(argv[i+1]);
			}
	}
	printf("dive params:Dive Time-%f\n  MF-%f\n  MB-%f\n",Timer,massF,massB);
	for (int i = 0;i<n;i++){
		singleDive((double)Timer,(double)massF,(double)massB);
		sleep(Timer+10);
	}
	printf("done");
}
