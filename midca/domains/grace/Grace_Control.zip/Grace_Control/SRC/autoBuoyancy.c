#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include <math.h>
#include "GliderFunIPC.h"

float currentPressure =0;
float depthRate = 0;
float pumpPos = 0;
float COB;
float COM;

float depthToPressure(float depth){
	 return depth/0.7038*.004+.521131;
 }
float getDepthRate(float derInterval){
	float depthLast=readFilteredPressure();
	usleep((int)(derInterval*1e6));
	currentPressure = readFilteredPressure();
	return (currentPressure - depthLast)/(derInterval);
}

void adjustPump(float gain,float targetPressure, float closeEnough,float interval){
	pumpPos=readPumpPercentage();
	depthRate = getDepthRate(interval);
	float noise = .002;
	int reachedPressure=0;
	printf("%f%%, %f\n",pumpPos,currentPressure);
	while(reachedPressure!=1){
		depthRate=getDepthRate(interval);
                if(fabsf(depthRate)<closeEnough){
                        COB = pumpPos;
                }
		if( fabsf(currentPressure-targetPressure)>.001){
			pumpPos = COB+ depthRate*gain + gain*(currentPressure-targetPressure); // simple controller
			//pumpPos = PIDcalculation(currentPressure-targetPressure,&pid);  //pid controller
			pumpPos = saturate(pumpPos,0.0,99.5);
			movePump(pumpPos);
		}
		if(currentPressure>targetPressure){reachedPressure=1;}
		printf("%f%%,%d,%f,%f\n",pumpPos,sgn(depthRate),depthRate,currentPressure);
		//usleep(20000);
	}
	COB = readPumpPercentage();
	//printf("%f%\n",balanceVal);
}

void trackDepth(float gain,float targetPressure, float closeEnough,float interval){
	pumpPos=readPumpPercentage();
	depthRate = getDepthRate(interval);
	//int edge=0;
	float noise = .002;
	int reachedPressure=0;
	//while(1){
	printf("%f%%, %f\n",pumpPos,currentPressure);
	while(fabsf(currentPressure-targetPressure)>closeEnough){
		depthRate=getDepthRate(interval);
		if( fabsf(currentPressure-targetPressure)>.001){
			pumpPos += depthRate*gain + gain*(currentPressure-targetPressure); // simple controller
			//pumpPos = PIDcalculation(currentPressure-targetPressure,&pid);  //pid controller
			pumpPos = saturate(pumpPos,0.0,99.5);
			movePump(pumpPos);
		}
		if(currentPressure>targetPressure){reachedPressure=1;}
		printf("%f%%,%d,%f,%f\n",pumpPos,sgn(depthRate),depthRate,currentPressure);
		//usleep(20000);
	}
	COB = readPumpPercentage();
	//printf("%f%\n",balanceVal);
}
void writeToFile(float val){
	FILE *fp;
	fp = fopen("Calibration/COB.txt", "w");
	fprintf(fp,"%f",val);
}
int main(int argc, char **argv){
	if (initIPC()<=0){
		printf("Could not connect to dataPipe.c\n");
		exit(-1);
	}
	logProgramStart(argc,argv);
    float gain = 1;
    float interval = 0.5;
    float targetDepth = 0;
    float diveTime;
    float targetPressure = 0;
    float tolerance = 0.25;
    float Kp = 0;
    float Ki = 0;
    float Kd = 0;
    int method  = 0;
    for (int i = 0;i<argc;i++){
			if(argv[i][0]=='-'){
				if(strcmp(argv[i]+1,"COB")==0)
					COB = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"COM")==0)
					COM = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"tolerance")==0)
					tolerance = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"depth")==0)
					targetDepth = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"method")==0)
					method = atoi(argv[i+1]);
				else if(strcmp(argv[i]+1,"kp")==0){
					Kp = atof(argv[i+1]);	
					method = 3;}
				else if(strcmp(argv[i]+1,"kd")==0){
					Kd = atof(argv[i+1]);		
					method = 3;}
				else if(strcmp(argv[i]+1,"ki")==0){
					Ki = atof(argv[i+1]);	
					method = 3;}
				else if(strcmp(argv[i]+1,"diveTime")==0)
					diveTime = atof(argv[i+1]);
			}
	}
	printf("params:Method-%f\n Dive Time-%f\n  targetDepth-%f\n  tolerance-%f\n tolerance-%f\n",method,diveTime,targetDepth,tolerance);
    movePump(55.5);
    targetPressure = depthToPressure(targetDepth);
    float temp=getDepthRate(10);
	while(temp>tolerance){
		if (method==0)
			adjustPump(gain,targetPressure,tolerance,interval);
		if (method==1)
			trackDepth(gain,targetPressure,0,interval);
		temp=getDepthRate(3);
		if (method==3){
			char cmd[100] = {0};
			sprintf(cmd,"./PIDconstantDepthDive -D %f -diveTime %f -kp %f -ki %f -kd %f &",targetDepth,diveTime,Kp,Ki,Kd);
			system(cmd);
			method = -1;
		}
			
	}		
	printf("%f%%\n",readPumpPercentage());
	movePump(99.8);
	
}
