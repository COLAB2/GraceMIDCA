#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include "GliderFunIPC.h"

int main(int argc, char **argv){
	if (initIPC()<=0){
		printf("Could not connect to dataPipe.c\n");
		exit(-1);
	}
	logProgramStart(argc,argv);
	if(readGPSValid() == 'A'){
		char cmd[50] ={0};
		sprintf(cmd,"sudo date -s @%lu",readGPSTime());
		return system(cmd);
	}
}
