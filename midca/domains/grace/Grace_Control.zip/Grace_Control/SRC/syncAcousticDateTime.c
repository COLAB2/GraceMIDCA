#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include <math.h>
#include <time.h>
#include "GliderFunIPC.h"
#define sgn(v) ((v<0)?-1:(v>0))

int main(int argc, char **argv){
	if (initIPC()<=0){
		printf("Could not connect to dataPipe.c\n");
		exit(-1);
	}
	syncAcousticDateTime(readGPSTime());
	logProgramStart(argc,argv);
}
