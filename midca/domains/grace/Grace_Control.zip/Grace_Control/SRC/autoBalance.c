#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include "GliderFunIPC.h"


float pitch;
float massPos;
float COB;
float COM;

void balance2(float step, float closeEnough){
	pitch = readPitch();
	massPos = readMassPercentage();
	printf("%f%%,%f\n",massPos,pitch);
	while(fabsf(pitch)>closeEnough){
	//while(1){
		pitch = readPitch();
		massPos += pitch*step;
		massPos = saturate(massPos,0.0,99.9);
		printf("%f%%,%d,%f\n",massPos,sgn(pitch),pitch);
		moveMass(massPos);
		usleep(20000);
	}
	COM = readMassPercentage();
}
void balance1(float gain, float closeEnough, float ts){
	pitch = readPitch();
	massPos = readMassPercentage();
	float lastPitch = pitch;
	while(fabsf(pitch)>closeEnough){
		pitch = readPitch();
		if(fabsf(pitch)<fabsf(lastPitch)){
			COM = readMassPercentage();
		}
		massPos = COM + pitch*gain;
		massPos = saturate(massPos,0.0,99.9);
        printf("%f%%,%d,%f\n",massPos,sgn(pitch),pitch);
		moveMass(massPos);
		lastPitch = pitch;
		usleep((int)(ts*1e6));
	}
	COM = readMassPercentage();
}
void balancePID(float closeEnough,float timestep,struct PID* pid){
	pitch = readPitch();
	while(fabsf(pitch)>closeEnough){
	    pid->dt = timestep;
		pitch = readPitch();
		massPos = PIDcalculation(pitch,pid);
		printf("%f%%,%d,%f\n",massPos,sgn(pitch),pitch);
		moveMass(saturate(massPos,0.0,99.9));
		usleep((int)(timestep*1e6));
	}
	COM = readMassPercentage();
}
void balance3(float gain,float gain2, float closeEnough, float ts){
	pitch = readPitch();
	massPos = readMassPercentage();
	float lastPitch = pitch;
	float lowestPitch = pitch;
	while(fabsf(pitch)>closeEnough){
		pitch = readPitch();
		float pr = readPitchRate();
		if(fabsf(pitch)<fabsf(lastPitch)){
				COM = readMassPercentage();//-pr*gain2;
		}
		massPos = COM + pitch*gain - pr*gain2;
		massPos = saturate(massPos,0.0,99.9);
        printf("%f%%,%d,%f\n",massPos,sgn(pitch),pitch);
		moveMass(massPos);
		lastPitch = pitch;
		usleep((int)(ts*1e6));
	}
	COM = readMassPercentage();
}

void balance4(float delta, float closeEnough, float ts){
	moveMass(100);
	while(readMassPercentage()<98);
	float p1 = fabs(readPitch());
	float mp1 = readMassPercentage();
	moveMass(0.01);
	while(readMassPercentage()>1);
	float p2 = fabs(readPitch());
	float mp2 = readMassPercentage();
	massPos = 0.5*(mp1*p2/(p1+p2)+mp2*p1/(p1+p2));
	moveMass(saturate(massPos,0.0,99.9));
	while(fabsf(readMassPercentage()-massPos)>1);
	pitch = readPitch();
	while(fabsf(pitch)>closeEnough){
		mp1 = massPos + delta;
		mp2 = massPos - delta;
		moveMass(mp1);
		while(fabsf(readMassPercentage()-mp1)>1){usleep((int)(.333*1e6));moveMass(mp1);}
		p1 = fabs(readPitch());
		mp1 = readMassPercentage();
		moveMass(mp2);
		while(fabsf(readMassPercentage()-mp2)>1){usleep((int)(.333*1e6));moveMass(mp2);};
		p2 = fabs(readPitch());
		mp2 = readMassPercentage();
		massPos = 0.5*(mp1*p2/(p1+p2)+mp2*p1/(p1+p2));
		moveMass(saturate(massPos,0.0,99.9));
		while(fabsf(readMassPercentage()-massPos)>1){usleep((int)(.333*1e6));moveMass(massPos);};
		usleep((int)(ts*1e6));
		pitch = readPitch();
	}
	COM = readMassPercentage();
}
void writeToFile(float val){
	FILE *fp;
	fp = fopen("Calibration/COM.txt", "w");
	fprintf(fp,"%f",val);
}
int main(int argc, char **argv){
	if (initIPC()<=0){
		printf("Could not connect to dataPipe.c\n");
		exit(-1);
	}
	logProgramStart(argc,argv);
	float tolerance = 5;
	float step = .1;
	float timestep = .3;
	float gain = 1;
	float gain2 = 10;
	float depth = -1;
	float diveTime;
	int method = 3;
	struct PID pid;
	pid.Kp = 13;
	pid.Ki = 0;
	pid.Kd = 850;
	pid.satFlag =0;
	for (int i = 0;i<argc;i++){
			if(argv[i][0]=='-'){
				if(strcmp(argv[i]+1,"COB")==0)
					COB = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"COM")==0)
					COM = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"kp")==0){
					pid.Kp = atof(argv[i+1]);	
					method = 0;}
				else if(strcmp(argv[i]+1,"kd")==0){
					pid.Kd = atof(argv[i+1]);		
					method = 0;}
				else if(strcmp(argv[i]+1,"ki")==0){
					pid.Ki = atof(argv[i+1]);	
					method = 0;}
				else if(strcmp(argv[i]+1,"ts")==0){
					timestep = atof(argv[i+1]);	
					}
				else if(strcmp(argv[i]+1,"tolerance")==0)
					tolerance = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"depth")==0)
					depth = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"diveTime")==0)
					diveTime = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"method")==0)
					method = atoi(argv[i+1]);
				else if(strcmp(argv[i]+1,"pitchGain")==0)
					gain = atoi(argv[i+1]);
				else if(strcmp(argv[i]+1,"pitchRateGain")==0)
					gain2 = atoi(argv[i+1]);
			}
	}
	if(depth>-1){
		char cmd[100] = {0};
		sprintf(cmd,"./PIDconstantDepthDive -D %f -diveTime %f &",depth,diveTime);
		system(cmd);
	}
	pitch = readPitch();
	while(fabsf(pitch)>tolerance){
		if (method==1){
			balance1(gain,tolerance,timestep);
		}
		if (method==2){
			balance2(step,tolerance);
		}
		if (method==3){
			balance3(gain,gain2,tolerance,timestep);
		}
		if (method==4){
			balance4(step,tolerance,timestep);
		}
		if (method==0){
			balancePID(tolerance,timestep,&pid);
		}
		sleep(3);
		pitch = readPitch();
		//printf("%f%,%f\n",massPos,pitch);
	}
	COM = readMassPercentage();		
	printf("%f$%%\n",COM);
}
