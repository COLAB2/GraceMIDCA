#include <wiringPiI2C.h> 
#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include <math.h>
#include "GliderFunIPC.h"
#define sgn(v) ((v<0)?-1:(v>0))

float pumpPos;


void ask(char* command){

    
    char *pch;
    char *type;
    char *mode;
    char *scan_vol;
    char *high;
    char *low;
    char *osc_time;
    char *fixed;
    
    int cnt = 0;
    pch = strtok(command, " \t_,");
    while(pch != NULL)
    {
		if(cnt == 0){
			type = pch;
			cnt++;
		}
		else if(cnt == 1){
			if(type[0] == 'M' || type[0] == 'P'){
				scan_vol = pch;
			}
			else if(type[0] == 'S'){
				mode = pch;
				cnt++;
			}
		}
		else if(cnt == 2){
			if(mode[0] == 'F'){
				fixed = pch;
			}
			else if(mode[0] == 'O')
			{
				high = pch;
				cnt++;
			}
		}
		else if(cnt == 3){
			
			low = pch;
			cnt++;
		}
		else if(cnt == 4){
			osc_time = pch;
			cnt++;
		}
		pch = strtok(NULL, " _,");
	}
	

	float f;
	int fixed_int;
	
	int high_int;
	int low_int;
	float time_float;

	// write mass or pump voltage to MCU
	if(type[0] == 'M')
	{
		f = atof(scan_vol);
		moveMass(f);
      printf("Moving to %f%%\n",f);
	}
	if( type[0] == 'P')
	{
		f = atof(scan_vol);
		movePump(f);
      printf("Moving to %f%%\n",f);
	}
	// write servo
	else if (type[0] == 'S')
	{
		if(mode[0] == 'F'){
			fixed_int = atoi(fixed);
			moveServo(fixed_int);
         printf("%d\n", fixed_int);
		}
		// oscillate the servo
		else if(mode[0] == 'O'){
			high_int = atoi(high);
			low_int = atoi(low);
			time_float = atof(osc_time);
			oscillateServo(high_int,low_int,time_float);
			printf("%d %d %f \n", high_int, low_int, time_float);
		}
	}
	if( type[0] == 'T')
	{
		f = atoi(scan_vol);
		setPropellerSpeed((int)f);
		printf("Speed to %d\n",(int)f);
	}
}

int main(int argc, char **argv){
	if (initIPC()<0){
		printf("Could not connect to dataPipe.c\n");
		exit(-1);
	}
	logProgramStart(argc,argv);
	if(argc==2){
		ask(argv[1]);
	}
		
	else if(argc==3){
		if (*argv[1]=='M'||*argv[1]=='m'){
			if (*argv[2]=='F'||*argv[2]=='f') moveMass(99.9);
			else if (*argv[2]=='B'||*argv[2]=='b') moveMass(0.002);
			else {moveMass(atof(argv[2]));
			printf("Moving to %f%%\n",atof(argv[2]));}
		}
		else if (*argv[1]=='P'||*argv[1]=='p'){
			if (*argv[2]=='F'||*argv[2]=='f') movePump(99.9);
			else if (*argv[2]=='B'||*argv[2]=='b') movePump(0.002);
			else {movePump(atof(argv[2]));
			printf("Moving to %f%%\n",atof(argv[2]));}
		}
		else if (*argv[1]=='S'||*argv[1]=='s'){
			if (*argv[2]=='L'||*argv[2]=='l') moveServo(45);
			else if (*argv[2]=='R'||*argv[2]=='r') moveServo(-45);
			else {moveServo(atoi(argv[2]));
			printf("Moving to %d degrees\n",atoi(argv[2]));}
		}
		else if (*argv[1]=='T'||*argv[1]=='t'){
			setPropellerSpeed(atoi(argv[2]));
			printf("Speed set to %d\n",atoi(argv[2]));
		}
	}
	else if (argc==5){
		if (*argv[1]=='S'||*argv[1]=='s'){
			oscillateServo(atof(argv[2]),atof(argv[3]),atof(argv[4]));
		}
	}
	else{
		//OPTS
		printf("\nCommand Line input:\n\tMove Mass-> M percentage\n\tMove Pump-> P percentage \n\tMove servo -> S angle\n\tOscillate Servo -> S bias amplitude flaptime\n\tSet thruster speed -> T speed<abs(100)");
		//END_OPTS
		printf("remap constant is %f.\n",pump_remap_constant);
		printf("\tMove Mass - M,Percentage \n\tMove servo - S,F,Angle\n\tOscillate Servo - S,O,bias,amplitude,time\n");
		printf("sample input: \n\tMove Pump - P_99.8");
		printf("\n\tMove Mass - M,2.0 \n\tMove servo - S,F,20\n\tOscillate Servo - S,O,0,20,0.500 \n\tSet thruster speed T,20\n input:");
		
		char command[256];
		scanf("%s", command);
		ask(command);
	}
}
