#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include <math.h>
#include <time.h>
#include <sys/time.h> //FD_SET, FD_ISSET, FD_ZERO macros 
#include "GliderFunIPC.h"
//#define sgn(v) ((v<0)?-1:(v>0))

float surfacePressure = 0;
float saturationPressure = 3.28;
int trackYaw = 0; //flag to determine if we should track yaw or nor
float targetYaw; // yaw angle we want to track
float amp = 45;  //tail flap amplitude
float flapTime = 0.5;  //tail flap time delay
int thrust = 0; // % of thuster speed (between -100 and 100)
int thrustFlag = 0; // tels us to pulse the thruster
int pulseFlag = 0; //switches truster on and off for pulsing
time_t timeThrust; //timer for thuster pulse
float COB;
float COM;
time_t divestart; // starts timer for dive
float abortTime = 5; //time to wait before giving up on dive in case we get stuck


void yawHandler(int ks){
	//printf("first yaw read = %f\n",readYaw());
	readYaw();
	if(trackYaw==1){
		float angle = readYaw();
		float currentDepth = pressureToDepth(readFilteredPressure());
		if(ks == 1 && readMassPercentage() <  COM  && currentDepth > 0.5){
			yawCompFlap(angle,targetYaw,amp,flapTime);
			//oscillateServo(saturate(angle-targetYaw,-45,45),amp,flapTime);//yawComp(angle,targetYaw);
		 }
		 else{
			//moveServo(saturate(angle-targetYaw,-45,45));// yawComp(angle,targetYaw);
			printf("desired bias: %f\n",yawComp(angle,targetYaw));
		 }
		 printf("target Yaw : %f, current Yaw : %f\n",targetYaw,angle);
		 char tmpMsg[100] = {0};
		 sprintf(tmpMsg,"python xbeeSender.py target Yaw : %f, current Yaw : %f\n",targetYaw,angle);
		 system(tmpMsg);
	}
	//printf("target Yaw : %f\n",targetYaw);
}
void thrustHandler(){
	if ( thrustFlag==1 && difftime(time(NULL),timeThrust)>1 && readMassPercentage() < COM && readFilteredPressure()> 0.5){
		timeThrust =time(NULL);
		if (pulseFlag==1){
			setPropellerSpeed(thrust);
			pulseFlag=0;
		}
		else{
			setPropellerSpeed(0);
			pulseFlag=1;
		}
	}
	if(readMassPercentage() > COM || readFilteredPressure() < 0.5 || readPitch()<5)
		setPropellerSpeed(0);
}
void abortMission(){
	moveMass(1);
	movePump(99);
	thrust = 40;
	float currentDepth = pressureToDepth(readFilteredPressure());
	float depthTop = pressureToDepth(readFilteredPressure());
	while (currentDepth > depthTop) {
		sleep(3);
		movePump(99);
		if(readMassPercentage()>3.0){moveMass(1);}
		//yawHandler(0);
		thrustHandler();
		currentDepth = pressureToDepth(readFilteredPressure());
		printf("current depth = %f\n",currentDepth);
		char tmpMsg[100] = {0};
		sprintf(tmpMsg,"python xbeeSender.py current depth=%f\n", currentDepth);
		system(tmpMsg);
		memset(tmpMsg,0,sizeof(tmpMsg));
		sprintf(tmpMsg,"python xbeeSender.py current angle=%f\n", readYaw());
		system(tmpMsg);
	}
	setPropellerSpeed(0);
	while(1){
		sleep(5);
		system("python xbeeSender.py mission aborted");
	}
}

void singleDivePID(double targetDepth, double massForward, double massBackward,struct PID* pid){
	struct timeval update,start;
	gettimeofday(&start, NULL);
	moveMass(massForward);
	usleep(300000);
	float currentDepth = pressureToDepth(readFilteredPressure());
	while(currentDepth<=targetDepth){
		gettimeofday(&update, NULL);
		pid->dt = (float)(update.tv_sec-start.tv_sec)+(float)(update.tv_usec-start.tv_usec)/1e6f;
		currentDepth = pressureToDepth(readFilteredPressure());	
		float newPos = COB + PIDcalculation(currentDepth-targetDepth,pid);
		//printf("newPos = %f\n",newPos);
		movePump(saturate(newPos,0.05,99));
		yawHandler(0);
		thrustHandler();
		gettimeofday(&start, NULL);
		usleep(300000);
		if (difftime(time(NULL),divestart)>abortTime){
			abortMission();
		}
		printf("%f\n",currentDepth);
	}
	movePump(99);
	moveMass(massBackward);
}

void regulateDepth(double targetDepth, double massPos, int kickstart,float delta,struct PID* pid){
	struct timeval update,start;
	pid->totalError = 0;
	pid->lastError=0;
	gettimeofday(&start, NULL);
	moveMass(massPos);
	usleep(300000);
	float currentDepth = pressureToDepth(readFilteredPressure());
	int startDir = sgn(currentDepth-targetDepth);										  
	printf("depth:current=%f,target=%f\nrange:%f-%f\n ",currentDepth,targetDepth,targetDepth-delta,targetDepth+delta);
	while(fabs(currentDepth-targetDepth)>=delta || sgn(currentDepth-targetDepth) != startDir){
		gettimeofday(&update, NULL);
		pid->dt = (float)(update.tv_sec-start.tv_sec)+(float)(update.tv_usec-start.tv_usec)/1e6f;
		currentDepth = pressureToDepth(readFilteredPressure());	
		float newPos = COB + PIDcalculation(currentDepth-targetDepth,pid);
		//printf("newPos = %f,PID= %f\n",newPos,newPos-COB);
		movePump(saturate(newPos,0.05,99));
		//if (kickstart == 1 && massPos <  COM && currentDepth > 1.5){oscillateServo(0,45,.5);}
		//if (currentDepth < 0.5){moveServo(0);}
		if(fabsf(massPos-readMassPercentage())>3.0){moveMass(massPos);}
		yawHandler(kickstart);
		thrustHandler();
		gettimeofday(&start, NULL);
		usleep(300000);
		if (difftime(time(NULL),divestart)>abortTime){
			abortMission();
		}
		//printf("depth:current=%f,target=%f\nrange:%f-%f\n ",currentDepth,targetDepth,targetDepth-delta,targetDepth+delta);
	}
	printf("Pump  = %f\n",readPumpPercentage());
}

int main(int argc, char **argv){
	if (initIPC()<=0){
		printf("Could not connect to dataPipe.c\n");
		exit(-1);
	}
	logProgramStart(argc,argv);
	//surfacePressure = calibrateSurfacePressure(10);
	surfacePressure = readSurfacePressure();
	printf("Avg. surface depth = %f\n", pressureToDepth(surfacePressure));
	struct PID pid;
	pid.Kp = 7;
	pid.Ki = 5;
	pid.Kd = 10;
	pid.satFlag = 1;
	pid.highSat = 7;
	pid.lowSat = 0;
	float tolerance = .08;
	float depth = 0;
	float depth2 = pressureToDepth(surfacePressure) - .03;
	float massF = _COM;
	float massB = _COM;
	float depthTop = pressureToDepth(surfacePressure)+pressureOffset;
	int kickstart = 0;
	COM = _COM;
	COB = _COB;
	int n = 1;
	printf("dive params:");
	for (int i = 0;i<argc;i++){
			if(argv[i][0]=='-'){
				if(strcmp(argv[i]+1,"COB")==0)
					COB = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"COM")==0)
					COM = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"D")==0)
					depth = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"D2")==0)
					depth2 = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"DT")==0)
					depthTop = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"MassF")==0)
					massF = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"MassB")==0)
					massB = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"n")==0)
					n = atoi(argv[i+1]);
				else if(strcmp(argv[i]+1,"kp")==0)
					pid.Kp = atof(argv[i+1]);	
				else if(strcmp(argv[i]+1,"kd")==0)
					pid.Kd = atof(argv[i+1]);	
				else if(strcmp(argv[i]+1,"ki")==0)
					pid.Ki = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"PIDSatFlag")==0)
					pid.satFlag = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"PIDHighSat")==0)
					pid.highSat = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"PIDLowSat")==0)
					pid.lowSat = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"tolerance")==0)
					tolerance = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"kickstart")==0)
					kickstart = 1;//atoi(argv[i+1]);
				else if(strcmp(argv[i]+1,"targetYaw")==0){
					targetYaw=atof(argv[i+1]);
					trackYaw = 1;
				}
				else if(strcmp(argv[i]+1,"abortTime")==0){
					abortTime=atof(argv[i+1]);
				}
				else if(strcmp(argv[i]+1,"thrust%")==0){
					thrust = atoi(argv[i+1]);
					thrustFlag = 1;
				}
				printf("\n \t%s: %s",argv[i]+1,argv[i+1]);
			}
	}
	abortTime = abortTime*60;
	timeThrust = time(NULL);
	if (depthTop < pressureToDepth(surfacePressure)) {
		printf("Specified top depth (%f) is less than computed surface depth.\n",depthTop);
		exit(-1);
	}	
	
	for (int i = 0; i < n; i++) {
		divestart = time(NULL);
		printf("Dive %d of %d\n",i+1,n);
		if(depth > pressureToDepth(surfacePressure) && depth2 > pressureToDepth(surfacePressure)){
			printf("2 depths\n");
			regulateDepth((double)max(depth,depth2),(double)massF,0,tolerance,&pid);
			
			printf("deep depth = %f\n",pressureToDepth(readFilteredPressure()));
			usleep(3000);
			regulateDepth((double)min(depth,depth2),(double)massB,kickstart,tolerance,&pid);
			if(kickstart == 1 && trackYaw == 1){
				float angle = readYaw();
				yawComp(angle, targetYaw);
			}
			else{
				moveServo(0);
			}
			setPropellerSpeed(0);
			printf("shallow depth = %f\n",pressureToDepth(readFilteredPressure()));
	    }
	    else{
			singleDivePID((double)depth,(double)massF,(double)massB,&pid);
			float currentDepth=pressureToDepth(readFilteredPressure());
			int mode = kickstart - trackYaw; //1 kickstart on yawtracking off, -1 yawtracking on kickstart off
			while (currentDepth > depthTop) {
				usleep(300000);
				currentDepth = pressureToDepth(readFilteredPressure());
				//if (mode == 1 && currentDepth < 0.5){yawHandler(kickstart);}
				//else if (mode == 1 && readMassPercentage() <  COM && currentDepth > 1.5){oscillateServo(0,45,.5);}
				if(fabsf(massB-readMassPercentage())>3.0){moveMass(massB);}
				yawHandler(kickstart);
				thrustHandler();
				printf("current depth = %f\n",currentDepth);
				char tmpMsg[100] = {0};
				sprintf(tmpMsg,"python xbeeSender.py current depth=%f\n", currentDepth);
				system(tmpMsg);
				memset(tmpMsg,0,sizeof(tmpMsg));
				sprintf(tmpMsg,"python xbeeSender.py current angle=%f\n", readYaw());
				system(tmpMsg);
			}
			setPropellerSpeed(0);
		}
		char tmpMsg[100] = {0};
		sprintf(tmpMsg,"python xbeeSender.py dive %d completion time: %f\n", n,difftime(time(NULL),divestart));
		system(tmpMsg);
	}
	float currentDepth=pressureToDepth(readFilteredPressure());
	movePump(99);
	moveMass(massB);
	int mode = kickstart - trackYaw; //1 kickstart on yawtracking off, -1 yawtracking on kickstart off
	while (currentDepth > depthTop) {
		sleep(3);
		movePump(99);
		//if (mode == 1 && currentDepth < 0.5){yawHandler(kickstart);}
		//else if (mode == 1 && readMassPercentage() <  COM && currentDepth > 1.5){oscillateServo(0,45,.5);}
		if(fabsf(massB-readMassPercentage())>3.0){moveMass(massB);}
		yawHandler(kickstart);
		thrustHandler();
		currentDepth = pressureToDepth(readFilteredPressure());
		printf("current depth = %f\n",currentDepth);
		char tmpMsg[100] = {0};
		sprintf(tmpMsg,"python xbeeSender.py current depth=%f\n", currentDepth);
		system(tmpMsg);
		memset(tmpMsg,0,sizeof(tmpMsg));
		sprintf(tmpMsg,"python xbeeSender.py current angle=%f\n", readYaw());
		system(tmpMsg);
	}
	moveServo(0);
	moveMass(COM);
	system("python xbeeSender.py dive sequence complete\n");
	//~ system("python xbeeSender.py dive started\n");
	//~ moveMass(0.1);
	//~ time_t delay = time(NULL);
	//~ float angle = readYaw();
				
	//~ while(difftime(time(NULL),delay)<=15){
		//~ angle = readYaw();
		//~ yawComp(angle, targetYaw);
		//~ usleep(500000);
	//~ }
	//~ moveMass(COM);
	//~ sleep(2);
	//~ system("python xbeeSender.py dive sequence complete\n");
}
