/*dataPipe.c
 * This program does 3 main things:
 *     1. continiously pulls data from the microcontroller to be used by other programs (updater thread)
 *     2. creates a unix domain socket that listens for multiple connectins (main loop)
 *     3. parses messages sent through connections to control robot or send data
 * */

#include <stdio.h>  
#include <string.h>   //strlen  
#include <stdlib.h>  
#include <errno.h>  
#include <unistd.h>   //close  
#include <sys/types.h>  
#include <sys/socket.h>  
#include <sys/un.h>
#include <sys/time.h> //FD_SET, FD_ISSET, FD_ZERO macros 
#include <wiringPi.h>
#include <math.h>
#include "GliderFun.h"

#define ACOUSTIC_PIN 4

int debug = 0;
//char *srv_name ="SAMA";
char *srv_name =SERVER_NAME;
int threadlock = 0;
int update = 1;
int varnum;
float updateIntervals[255]; // get time between updates for variables
//variables to update
long gpTime;
long gpDate;
char gpValidStatus;
float lattitude;
float longitude;
char latFlag;
char longFlag;
float servo_angle;
float roll;
float pitch;
float yaw;
float yawRate;
float rollRate;
float pitchRate;
float x_accel;
float y_accel;
float z_accel;
float imuTemp;
float imuPressure;
float pressure;
float pressure_avg;
float pressure_filt;
float surfacePressure = 0;
int inTemp;
float massPercent;
float targetMassPercentage;
float pumpPercent;
float targetPumpPercentage = 99.9;
float DO_temp;
float DO_sat;
float DO_con;
float DO_pps;
float algae;
float chlorophyl;
float par;
float batt_voltage;
char acousticMSG[1024];
int acousticFlag = 0;

int servo_angle1;
int servo_angle2;
float flap_time;
int flap_flag = 0;
int flap_direction = 0;


void acousticInterrupt(void){
	acousticFlag = 1;
}

void sendVar(void* var,int sz,int sd){
	float f;
	//memcpy(&f,(char *)var,sizeof(f));
	memcpy(&f,var,sizeof(f));
	if(debug==1){printf("sending %f,%d\n",f,sz);}
	//send(sd,(char *)var,sz,0);
	write(sd,var,sz);
	if(debug==1){printf("sent %f,%d\n",f,sz);}
}
void sendLongString(long var,int sd){
	char msg[1024] = {0};
	sprintf(msg,"%lu",var);
	int sz = strlen(msg);
	//printf("sending %lu\n",var);
	if(send(sd,msg,sz,MSG_NOSIGNAL) != sz){
		return;//perror("send");  
	}
	if(debug==1){printf("sent %lu\n",var);}
}
void sendFloatString(float var,int sd){
	char msg[1024] = {0};
	sprintf(msg,"%.4f",var);
	int sz = strlen(msg);
	//printf("sending %f\n",var);
	if(send(sd,msg,sz,MSG_NOSIGNAL) != sz){
		return;//perror("send");  
	}
	if(debug==1){printf("sent %f\n",var);}
}

PI_THREAD(updaterThread){
	varnum = mmcu_varnum+misc_varnum+emcu_varnum;
	if(debug==1){printf("initiating mcu\n");}
	initMain(0x32);
	initBattMon(0x18);
	initEnvSensors(0x39);
	initPropeller(0x38);	
	initAcousticReciever(0x36);			 
	memset(updateIntervals,0,varnum*sizeof(updateIntervals[0]));
	struct timeval updateTimer,start;
	gettimeofday(&start, NULL);
	gettimeofday(&updateTimer, NULL);
	float last[varnum+5];
	float current;
	float dummyFloat = 0;
	float dummyFloat2 = 0;
	sleep(20);
	memset(last,0,varnum);
	int samples = 20;
	int scount = 0;
	for (int i = 0; i < samples; i++) {
		usleep(10000);
		dummyFloat= readFilteredPressure();	
		if (dummyFloat<=3.3 && dummyFloat>= 0)//0.45)
			surfacePressure += dummyFloat;
		else
			i--;
			
		if(debug==1)printf("%d - %f\r\n",i+1,surfacePressure);
		//~ if(scount > 5*samples){
			//~ printf("check pressure sensor");
			//~ break;
		//~ }
		scount++;
		//if (scount > 5*samples){
			//i = min(
	}
	surfacePressure = surfacePressure/(float)samples;
	if(debug==1)printf("%f\r\n",surfacePressure);
	float maxInterval = 0;
	int i;
	for(i=0;i<varnum;i++){updateIntervals[i]=.1;}
	for(i=0;i<varnum;i=(i+1)%varnum){ //infinite for loop
		if(update){
			gettimeofday(&updateTimer, NULL);
		}
		//printf("%d\n",i);
		current = (float)(updateTimer.tv_sec-start.tv_sec)+(float)(updateTimer.tv_usec-start.tv_usec)/1e6f;
		if (acousticFlag==1){
			piLock(threadlock);
			readAcoustic(acousticMSG);
			resetAcousticPin();
			piUnlock(threadlock);
			char sendmsg[1024]="echo \"";
			strncat(sendmsg,acousticMSG,strlen(acousticMSG)-1);
			strcat(sendmsg," \" >> /home/pi/Desktop/Grace_Control/DATALOG/acousticRcvr.csv");
			if(debug==1)printf("%s\n",acousticMSG);
			system(sendmsg);
			acousticFlag = 0;
		}
		else if(digitalRead(ACOUSTIC_PIN)==1){
			resetAcousticPin();
		}
		if (flap_flag == 1) {
			if (flap_time<= current-last[varnum + 1] && flap_direction == 0){
				piLock(threadlock);
				moveServo(servo_angle1);
				piUnlock(threadlock);
				flap_direction = 1;
				//printf("last: %f,current: %f\n",last[varnum + 1],current);
				last[varnum + 1] = current;
			}
			else if (flap_time <= current-last[varnum + 1] && flap_direction == 1){
				piLock(threadlock);
				moveServo(servo_angle2);
				piUnlock(threadlock);
				flap_direction = 0;
				//printf("last: %f,current: %f\n",last[varnum + 1],current);
				last[varnum + 1] = current;
			}
			
		}
		else if (45 <= current-last[varnum + 2]){//check servo positions every 45 sec if not oscillating
			if (fabsf(servo_angle-servo_angle1)>10){
				piLock(threadlock);
				moveServo(servo_angle1);
				piUnlock(threadlock);
			}
			last[varnum + 2] = current;
		}
		if (45 <= current-last[varnum + 3]){//check pump and mass positions every 45 sec
			if (fabsf(targetMassPercentage-massPercent)>10){
				piLock(threadlock);
				moveMass(targetMassPercentage);
				piUnlock(threadlock);
			}
			if (fabsf(targetPumpPercentage*pump_remap_constant-pumpPercent)>15){
				piLock(threadlock);
				movePump(targetPumpPercentage);
				piUnlock(threadlock);
			}
			last[varnum + 3] = current;
		}
		if ((updateIntervals[i]<=current-last[i]) && updateIntervals[i]>0){
			char check = (char)i;
			if (i >= mmcu_varnum){
				check = (char)(i%mmcu_varnum);
			}
			if (i >= mmcu_varnum+emcu_varnum){
				check = (char)(i%(mmcu_varnum+emcu_varnum));
			}
			//printf("%d,%d\n",(int)check,i);
			//printf("%f\n",updateIntervals[i]);
			piLock(threadlock);
			if((char)i==SERVO_READ && i< mmcu_varnum){
				dummyFloat2 =readServoAngle();
				dummyFloat = readServoAngle();
				if (fabsf(dummyFloat)<=180.0 && fabsf(dummyFloat-dummyFloat2)<5.1) {servo_angle = dummyFloat;}			
			}
			else if((char)i==MASS_READ && i< mmcu_varnum){
				dummyFloat2 = readMassPercentage();
				dummyFloat = readMassPercentage();	
				if (dummyFloat<=100.0 && dummyFloat>= 0.0 && fabsf(dummyFloat-dummyFloat2)<10.1){massPercent = dummyFloat;}	
			}
			else if((char)i==PUMP_READ && i< mmcu_varnum) {
				dummyFloat2 = readPumpPercentage();
				dummyFloat = readPumpPercentage();	
				if (dummyFloat<=100.0 && dummyFloat>= 0.0 && fabsf(dummyFloat-dummyFloat2)<5.1){pumpPercent = dummyFloat;}	
			}
			else if((char)i==PRESSURE_READ && i< mmcu_varnum){
				dummyFloat = readPressure();		
				if (dummyFloat<=3.3 && dummyFloat>= 0){pressure = dummyFloat;}
			}
			else if((char)i==PRESSURE_AVG_READ && i< mmcu_varnum){
				dummyFloat= readAveragedPressure();
				if (dummyFloat<=3.3 && dummyFloat>= 0){pressure_avg = dummyFloat;}		
			}
			else if((char)i==PRESSURE_BWF_READ && i< mmcu_varnum){
				dummyFloat= readFilteredPressure();	
				if (dummyFloat<=3.3 && dummyFloat>= 0){pressure_filt = dummyFloat;}	
			}
			else if((char)i==GPS_TIME_READ && i< mmcu_varnum){
				long t1 = readGPSTime();
				long t2 = readGPSTime();		
				if(fabsf((float)t1-(float)t2)<20){gpTime = t2;}	
			}
			else if((char)i==GPS_DATE_READ && i< mmcu_varnum){
				gpDate = readGPSDate();			
			}
			else if((char)i==GPS_LAT_READ && i< mmcu_varnum){
				dummyFloat2= readLattitude();
				dummyFloat= readLattitude();			
				if (fabsf(dummyFloat)<=90.0 && fabsf(dummyFloat-dummyFloat2)<5){lattitude = dummyFloat;}
			}
			else if((char)i==GPS_LONG_READ && i< mmcu_varnum){
				dummyFloat2= readLongitude();
				dummyFloat= readLongitude();	
				if (fabsf(dummyFloat)<=180.0 && fabsf(dummyFloat-dummyFloat2)<5){longitude = dummyFloat;}		
			}
			else if((char)i==GPS_NS_FLAG_READ && i< mmcu_varnum){
				latFlag= readLatFlag();			
			}
			else if((char)i==GPS_EW_FLAG_READ && i< mmcu_varnum){
				longFlag= readLongFlag();			
			}
			else if((char)i==GPS_VALID_READ && i< mmcu_varnum){
				gpValidStatus = readGPSValid();			
			}
			else if((char)i==IMU_ROLL_READ && i< mmcu_varnum){
				dummyFloat2= readRoll();	
				dummyFloat= readRoll();	
				if (fabsf(dummyFloat)<=180.0 && fabsf(dummyFloat-dummyFloat2)<10.0){roll = dummyFloat;}	
			}
			else if((char)i==IMU_ROLL_RATE_READ && i< mmcu_varnum){
				dummyFloat2= readRollRate();
				dummyFloat= readRollRate();		
				if (fabsf(dummyFloat-dummyFloat2)<1.1 && fabsf(dummyFloat)<50){rollRate = dummyFloat;}		
			}
			else if((char)i==IMU_PITCH_READ && i< mmcu_varnum){
				dummyFloat2= readPitch();
				dummyFloat= readPitch();			
				if (fabsf(dummyFloat)<=180.0 && fabsf(dummyFloat-dummyFloat2)<10.0){pitch = dummyFloat;}	
			}
			else if((char)i==IMU_PITCH_RATE_READ && i< mmcu_varnum){
				dummyFloat2= readPitchRate();
				dummyFloat= readPitchRate();	
				if (fabsf(dummyFloat-dummyFloat2)<1.1 && fabsf(dummyFloat)<50){pitchRate = dummyFloat;}			
			}
			else if((char)i==IMU_YAW_READ && i< mmcu_varnum){
				dummyFloat2= readYaw();
				dummyFloat= readYaw();	
				if (fabsf(dummyFloat)<=180.0 && fabsf(dummyFloat-dummyFloat2)<10.0){yaw = dummyFloat;}			
			}
			else if((char)i==IMU_YAW_RATE_READ && i< mmcu_varnum){
				dummyFloat2= readYawRate();
				dummyFloat= readYawRate();	
				if (fabsf(dummyFloat-dummyFloat2)<1.1 && fabsf(dummyFloat)<50){yawRate = dummyFloat;}			
			}
			else if((char)i==IMU_ACCEL_X_READ && i< mmcu_varnum){
				dummyFloat2= readAccelX();
				dummyFloat= readAccelX();	
				if (fabsf(dummyFloat-dummyFloat2)<0.1 && fabsf(dummyFloat)<50){x_accel = dummyFloat;}		
			}
			else if((char)i==IMU_ACCEL_Y_READ && i< mmcu_varnum){
				dummyFloat2= readAccelY();
				dummyFloat= readAccelY();	
				if (fabsf(dummyFloat-dummyFloat2)<0.1 && fabsf(dummyFloat)<50){y_accel = dummyFloat;}			
			}
			else if((char)i==IMU_ACCEL_Z_READ && i< mmcu_varnum){
				dummyFloat2= readAccelZ();
				dummyFloat= readAccelZ();	
				if (fabsf(dummyFloat-dummyFloat2)<0.1 && fabsf(dummyFloat)<50){z_accel = dummyFloat;}			
			}
			else if((char)i==IMU_Temperature_READ && i< mmcu_varnum){
				dummyFloat=readIMUTemperature();	
				if(fabsf(dummyFloat)<500){imuTemp= dummyFloat;}			
			}
			else if((char)i==IMU_PRESSURE_READ && i< mmcu_varnum){
				dummyFloat=readIMUPressure();	
				if(dummyFloat<500 && dummyFloat> 50 ){imuPressure= dummyFloat;}			
			}
			else if(check==BATT_TEMP_READ && i>= mmcu_varnum+emcu_varnum){
				inTemp= readInTemp();				
			}
			else if(check==BATT_READ && i >= mmcu_varnum+emcu_varnum){
				batt_voltage= readBattery();		
			}
			else if(check==DO_TEMP_READ && i>= mmcu_varnum){
				dummyFloat=readDOTEMP();	
				if(fabsf(dummyFloat)<10000){DO_temp= dummyFloat;}		
			}
			else if(check==DO_CONC_READ && i>= mmcu_varnum){
				dummyFloat= readDOCON();
				if(fabsf(dummyFloat)<10000){DO_con=dummyFloat;}		
			}
			else if(check==DO_SAT_READ && i>= mmcu_varnum){
				dummyFloat= readDOSAT();
				if(fabsf(dummyFloat)<10000){DO_sat=dummyFloat;}
			}
			else if(check==DO_PAR_PRESS_READ && i>= mmcu_varnum){
				dummyFloat= readDOPPS();
				if(fabsf(dummyFloat)<10000){DO_pps=dummyFloat;}		
			}
			else if(check==CYC1_READ && i>= mmcu_varnum){
				dummyFloat2 = readAlgaeCy();	
				dummyFloat = readAlgaeCy();	
				if (dummyFloat<=3.3 && dummyFloat>= 0.0 && fabsf(dummyFloat-dummyFloat2)<0.5){algae = dummyFloat;}
			}
			else if(check==CYC2_READ && i>= mmcu_varnum){
				dummyFloat2 = readChlorophylCy();
				dummyFloat = readChlorophylCy();	
				if (dummyFloat<=3.3 && dummyFloat>= 0.0 && fabsf(dummyFloat-dummyFloat2)<0.5){chlorophyl = dummyFloat;}	
			}
			else if(check==PAR_READ && i>= mmcu_varnum){
				dummyFloat2= readPar2();
				dummyFloat= readPar2();
				if (dummyFloat<=3.3 && dummyFloat>= 0.0 && fabsf(dummyFloat-dummyFloat2)<0.5){par = dummyFloat;}					
			}
			piUnlock(threadlock);
			//printf("%2d,%.2f,%.2f,%.2f\n",i,current,last[i],updateIntervals[i]);
			last[i]=current;
		}
		if(updateIntervals[i]>maxInterval){maxInterval=updateIntervals[i];}
		//if(i+1==varnum && maxInterval<=1e-4){delay(2);}
		//if(i+1==varnum){maxInterval=0;}		
	}

	return 0;	
}

void parse(char* val,int sd){
	if (strlen(val)<1){return;}
	if(debug==1){printf("%s, client %d\n",val,sd);}
	void* message;
	int msg_size = strlen(val);
	char temp[msg_size];
	strcpy(temp,val); 
	if(debug==1){printf("%s, client %d\n",temp,sd);}
	int sendString = 0;
	//read message structure : R,source,varToRead,-s(optional to recieve as string)
	//                         MR(multiple read),source,var1,source,var2,..,source, varn,-s(optional)
	//send actuator command  : MV,actuator_indicator,val(or STP for stop)
	//                         OSC,High_angle,low_angle,flap_time
	//                         OSBA,bias,amplitude,flap_time
	//                         SET,upadte_interval,source,variable
	int argCount = 0;
	int extraMessage = -1;
	for (int i=0;i<msg_size;i++){//prep msg for parsing
		if (temp[i]=='\0'){//stop at first null character
			break;
		}
		else if (temp[i] == ','){//replace commas with null character
			temp[i]='\0';
			argCount+=1;
		}
		else if (temp[i]=='-'){//check if we want string output
			if(temp[i+1]=='s'||temp[i+1]=='S'){sendString = 1;}
		}
		else if (temp[i] == '\n'){//check for compounded messages
			temp[i] = '\0';
			if (temp[i+1]=='\0'){//stop at first null character
				break;
			}
			else{
				extraMessage = i+1;
				break;
			}
		}
	}
	char* arg = temp;
	if(debug==1){printf("arg %s, argCount %d\n",arg,argCount);}
	if (strncmp(arg,"R",strlen(arg))==0 ){//then we want to read a variable&& (argCount>=2)
	      char choice;
	      if(debug==1){printf("Reading: ");}
	      arg += strlen(arg)+1;	
	      if(debug==1){printf("arg %s,%d\n",arg,sendString);}
	      if (strncmp(arg,RPI_TAG,strlen(arg))==0 ){
			 arg += strlen(arg)+1;
			 int ch = atoi(arg);
			 piLock(threadlock);
				if(ch==SURFACE_PRESSURE){
					//printf("sP1 = %f \n",surfacePressure);
					if (sendString ==1){sendFloatString(surfacePressure,sd);}
					else{
						message = &surfacePressure;
						sendVar(message,sizeof(surfacePressure),sd);
					}
				}
			 //printf("sP = %f \n",surfacePressure);
			 piUnlock(threadlock);
		  }
		  if (strncmp(arg,MAIN_MCU_TAG,strlen(arg))==0 ){
			arg += strlen(arg)+1;
			if(debug==1){printf("arg %s\n",arg);}	
			piLock(threadlock);
			choice = (char)atoi(arg);
			if(choice==SERVO_READ){
				if (sendString ==1){sendFloatString(servo_angle,sd);}
				else{
					message = &servo_angle;
					sendVar(message,sizeof(servo_angle),sd);
				}		
			}
			else if(choice==MASS_READ){
				if (sendString ==1){sendFloatString(massPercent,sd);}
				else{
					message = &massPercent;
					sendVar(message,sizeof(massPercent),sd);
				}		
			}
			else if(choice==PUMP_READ) {
				if (sendString ==1){sendFloatString(pumpPercent,sd);}
				else{
					message = &pumpPercent;
					sendVar(message,sizeof(pumpPercent),sd);
				}				
			}
			else if(choice==PRESSURE_READ){
				if (sendString ==1){sendFloatString(pressure,sd);}
				else{
					message = &pressure;
					sendVar(message,sizeof(pressure),sd);
				}		
			}
			else if(choice==PRESSURE_AVG_READ){
				if (sendString ==1){sendFloatString(pressure_avg,sd);}
				else{
					message = &pressure_avg;
					sendVar(message,sizeof(pressure_avg),sd);
				}			
			}
			else if(choice==PRESSURE_BWF_READ){
				if (sendString ==1){sendFloatString(pressure_filt,sd);}
				else{
					message = &pressure_filt;
					sendVar(message,sizeof(pressure_filt),sd);
				}			
			}
			else if(choice==GPS_TIME_READ){
				if (sendString ==1){sendLongString(gpTime,sd);}
				else{
					message = &gpTime;
					sendVar(message,sizeof(gpTime),sd);
				}			
			}
			else if(choice==GPS_DATE_READ){
				if (sendString ==1){sendLongString(gpDate,sd);}
				else{
					message = &gpDate;
					sendVar(message,sizeof(gpDate),sd);
				}				
			}
			else if(choice==GPS_LAT_READ){
				if (sendString ==1){sendFloatString(lattitude,sd);}
				else{
					message = &lattitude;
					sendVar(message,sizeof(lattitude),sd);
				}				
			}
			else if(choice==GPS_LONG_READ){
				if (sendString ==1){sendFloatString(longitude,sd);}
				else{
					message = &longitude;
					sendVar(message,sizeof(longitude),sd);
				}		
			}
			else if(choice==GPS_NS_FLAG_READ){
				send(sd,&latFlag,1,0);			
			}
			else if(choice==GPS_EW_FLAG_READ){
				send(sd,&longFlag,1,0);			
			}
			else if(choice==GPS_VALID_READ){
				send(sd,&gpValidStatus,1,0);			
			}
			else if(choice==IMU_ROLL_READ){
				if (sendString ==1){sendFloatString(roll,sd);}
				else{
					message = &roll;
					sendVar(message,sizeof(roll),sd);
				}			
			}
			else if(choice==IMU_ROLL_RATE_READ){
				if (sendString ==1){sendFloatString(rollRate,sd);}
				else{
					message = &rollRate;
					sendVar(message,sizeof(rollRate),sd);
				}			
			}
			else if(choice==IMU_PITCH_READ){
				if (sendString ==1){sendFloatString(pitch,sd);}
				else{
					message = &pitch;
					sendVar(message,sizeof(pitch),sd);
				}			
			}
			else if(choice==IMU_PITCH_RATE_READ){
				if (sendString ==1){sendFloatString(pitchRate,sd);}
				else{
					message = &pitchRate;
					sendVar(message,sizeof(pitchRate),sd);
				}				
			}
			else if(choice==IMU_YAW_READ){
				if (sendString ==1){sendFloatString(yaw,sd);}
				else{
					message = &yaw;
					sendVar(message,sizeof(yaw),sd);
				}	
			}
			else if(choice==IMU_YAW_RATE_READ){
				if (sendString ==1){sendFloatString(yawRate,sd);}
				else{
					message = &yawRate;
					sendVar(message,sizeof(yawRate),sd);
				}	
			}
			else if(choice==IMU_ACCEL_X_READ){
				if (sendString ==1){sendFloatString(x_accel,sd);}
				else{
					message = &x_accel;
					sendVar(message,sizeof(x_accel),sd);
				}				
			}
			else if(choice==IMU_ACCEL_Y_READ){
				if (sendString ==1){sendFloatString(y_accel,sd);}
				else{
					message = &y_accel;
					sendVar(message,sizeof(y_accel),sd);
				}
			}
			else if(choice==IMU_ACCEL_Z_READ){
				if (sendString ==1){sendFloatString(z_accel,sd);}
				else{
					message = &z_accel;
					sendVar(message,sizeof(z_accel),sd);
				}			
			}
			else if(choice==IMU_Temperature_READ){
				if (sendString ==1){sendFloatString(imuTemp,sd);}
				else{
					message = &imuTemp;
					sendVar(message,sizeof(imuTemp),sd);
				}			
			}
			else if(choice==IMU_PRESSURE_READ){
				if (sendString ==1){sendFloatString(imuPressure,sd);}
				else{
					message = &imuPressure;
					sendVar(message,sizeof(imuPressure),sd);
				}
			}
			piUnlock(threadlock);
		  }
		  else if (strncmp(arg,SENSOR_MCU_TAG,strlen(arg))==0 ){
			 arg += strlen(arg)+1;	
			 choice = (char)atoi(arg);
			 if(choice==DO_TEMP_READ){
				if (sendString ==1){sendFloatString(DO_temp,sd);}
				else{
					message = &DO_temp;
					sendVar(message,sizeof(DO_temp),sd);
				}			
			}
			else if(choice==DO_CONC_READ){
				if (sendString ==1){sendFloatString(DO_con,sd);}
				else{
					message = &DO_con;
					sendVar(message,sizeof(DO_con),sd);
				}
			}
			else if(choice==DO_SAT_READ){
				if (sendString ==1){sendFloatString(DO_sat,sd);}
				else{
					message = &DO_sat;
					sendVar(message,sizeof(DO_sat),sd);
				}			
			}
			else if(choice==DO_PAR_PRESS_READ){
				if (sendString ==1){sendFloatString(DO_pps,sd);}
				else{
					message = &DO_pps;
					sendVar(message,sizeof(DO_pps),sd);
				}				
			}
			else if(choice==CYC1_READ){
				if (sendString ==1){sendFloatString(algae,sd);}
				else{
					message = &algae;
					sendVar(message,sizeof(algae),sd);
				}				
			}
			else if(choice==CYC2_READ){
				if (sendString ==1){sendFloatString(chlorophyl,sd);}
				else{
					message = &chlorophyl;
					sendVar(message,sizeof(chlorophyl),sd);
				}				
			}
			else if(choice==PAR_READ){
				if (sendString ==1){sendFloatString(par,sd);}
				else{
					message = &par;
					sendVar(message,sizeof(par),sd);
				}	
			}
			piUnlock(threadlock);
		  }
		  else if (strncmp(arg,BATT_MON_TAG,strlen(arg))==0 ){
			arg += strlen(arg)+1;	
			piLock(threadlock);
			choice = (char)atoi(arg);
			if(choice==BATT_TEMP_READ){
				if (sendString ==1){sendFloatString((float)inTemp,sd);}
				else{
					message = &inTemp;
					sendVar(message,sizeof(inTemp),sd);
				}				
			}
			else if(choice==BATT_READ){
				if (sendString ==1){sendFloatString(batt_voltage,sd);}
				else{
					message = &batt_voltage;
					sendVar(message,sizeof(batt_voltage),sd);
				}			
			}
			piUnlock(threadlock);  
		  }
		  else if (strncmp(arg,ACOUSTIC_RECIEVER_MCU_TAG,strlen(arg))==0 ){
			  arg += strlen(arg)+1;
			  choice = (char)atoi(arg);
			  if(choice==ACOUSTIC_READ){
				  send(sd,acousticMSG,strlen(acousticMSG),MSG_NOSIGNAL);
			  }
			  if(choice==ACOUSTIC_SYNC_TIME){
				  arg += strlen(arg)+1;
				  syncAcousticDateTime(atol(arg));
			  }
		  }
	}
	else if (strncmp(arg,"MR",strlen(arg))==0){
		  
	}
	else if (strncmp(arg,"MV",strlen(arg))==0 && argCount == 2){
		if(debug==1){printf("Moving something\n");}
		arg += strlen(arg)+1;
		if(debug==1){printf("arg %s\n",arg);	}
		if (arg[0] == 'S' || arg[0] == 's'){
			flap_flag = 0;
			arg += strlen(arg)+1;
			if(debug==1){printf("arg %s\n",arg);}
			piLock(threadlock); 
			if(arg[0] == 'S' || arg[0] == 's'){
				servo_angle=servo_angle1;//stopServo();
			}
			else{
				servo_angle1 = atoi(arg);
				moveServo(servo_angle1);	
				if(debug==1){printf("servo to %d\n",servo_angle1);}
			}						 
			piUnlock(threadlock);
		}
		else if (arg[0] == 'M' || arg [0]== 'm'){
			arg += strlen(arg)+1;
			piLock(threadlock); 
			if(arg[0] == 'S' || arg[0] == 's'){
				stopMass();
			}
			else{
				targetMassPercentage = atof(arg);
				moveMass(targetMassPercentage);
			}						 
			piUnlock(threadlock);	
		}
		else if (arg[0] == 'T' || arg [0]== 't'){
			arg += strlen(arg)+1;
			piLock(threadlock); 
			if(arg[0] == 'S' || arg[0] == 's'){
				//stopPropeller();
			}
			else{
				setPropellerSpeed(-atoi(arg));
			}						 
			piUnlock(threadlock);
		}	
		else if (arg[0] == 'P' || arg[0] == 'p'){
			arg += strlen(arg)+1;
			piLock(threadlock); 
			if(arg[0] == 'S' || arg[0] == 's'){
				stopPump();
			}
			else{
				if(atof(arg)>0.0){targetPumpPercentage=atof(arg); movePump(targetPumpPercentage);}
			}						 
			piUnlock(threadlock);
			if(debug==1){printf("arg %s\n",arg);}
		}
		else if (arg[0] == 'I' || arg [0]== 'i'){
			arg += strlen(arg)+1;
			if (strncmp(arg,"Tare",strlen(arg))==0){
				piLock(threadlock); 
				TareIMU();						 
				piUnlock(threadlock);
			}
			else if (strncmp(arg,"Save",strlen(arg))==0){
				piLock(threadlock); 
				SaveIMU();					 
				piUnlock(threadlock);
			}
			printf("%s\n",arg);
		}
		else if (arg[0] == IMU_HEADING_MODE){
			arg += strlen(arg)+1;
			SetHeadingIMU(atoi(arg));
		}
		
	}
	else if (strncmp(arg,"OSC",strlen(arg))==0 && argCount==3){
		 if(debug==1){printf("oscillate 2\n");}
		 arg += strlen(arg)+1;
		 //int h_angle = atoi(arg);
		 servo_angle1 = atoi(arg);
		 arg += strlen(arg)+1;
		 //int l_angle = atoi(arg);
		 servo_angle2 = atoi(arg);
		 arg += strlen(arg)+1;
		 flap_time = atof(arg);
		 flap_flag = 1;
		 //oscillateServo2(h_angle,l_angle,flap_time);
	}
	else if (strncmp(arg,"OSBA",strlen(arg))==0 && argCount==3){
		 if(debug==1){printf("oscilate 1\n");}
		 arg += strlen(arg)+1;
		 int bias = atoi(arg);
		 arg += strlen(arg)+1;
		 int amplitude = atoi(arg);
		 arg += strlen(arg)+1;
		 flap_time = atof(arg);
		 flap_flag = 1;
		 //oscillateServo(bias,amplitude,flap_time);
		int val = (int)(bias+amplitude);
		servo_angle1 = ((val>SERVO_MAX_ANGLE)?SERVO_MAX_ANGLE:val);// min 
		val = (int)(bias-amplitude);
		servo_angle2 = ((val>SERVO_MIN_ANGLE)?val:SERVO_MIN_ANGLE); //max
	}
	else if (strncmp(arg,"SET",strlen(arg))==0){
		if(debug==1){printf("setting something\n");}
		arg += strlen(arg)+1;
		if (strncmp(arg,MAIN_MCU_TAG,strlen(arg))==0 ){
			arg += strlen(arg)+1;
			if(debug==1){printf("arg %s\n",arg);}
			float setTime = atof(arg);
			arg += strlen(arg)+1;
			if(debug==1){printf("arg %s\n",arg);	}
			updateIntervals[atoi(arg)]=setTime;
		}
		else if (strncmp(arg,SENSOR_MCU_TAG,strlen(arg))==0 ){
			arg += strlen(arg)+1;
			if(debug==1){printf("arg %s\n",arg);}
			float setTime = atof(arg);
			arg += strlen(arg)+1;
			if(debug==1){printf("arg %s\n",arg);	}
			updateIntervals[atoi(arg)+mmcu_varnum]=setTime;
		}
		else if (strncmp(arg,BATT_MON_TAG,strlen(arg))==0 ){
			arg += strlen(arg)+1;
			if(debug==1){printf("arg %s\n",arg);}
			float setTime = atof(arg);
			arg += strlen(arg)+1;
			if(debug==1){printf("arg %s\n",arg);	}
			updateIntervals[atoi(arg)+mmcu_varnum+emcu_varnum]=setTime;
		}
		else if (strncmp(arg,RPI_TAG,strlen(arg))==0){
			arg += strlen(arg)+1;
			if(atoi(arg)==SURFACE_PRESSURE){
				arg += strlen(arg)+1;
				surfacePressure = atof(arg);
			}
		}
		if(debug==1){printf("arg %s\n",arg);	}
	}
    if (extraMessage>0) {
		if(debug==1){printf("processing compounded message: %s\n",temp+extraMessage);}
		parse(temp+extraMessage,sd);
	}	
}

int main(int argc, char **argv){
	for (int i = 0;i<argc;i++){
			if(argv[i][0]=='-'){
				if(strcmp(argv[i]+1,"dbg")==0)
					debug = 1;
			}
	}
	if(debug==1){printf("creating socket\n");}
	char buff[1024];
	int master_sock;
	int curr_cli = 0;
    int addrlen , new_socket,  
          max_clients = 40 , 
		  activity, 
		  i , 
		  valread ,
		  sd;   
    int max_sd,
	    client_socket[max_clients];  
	memset(client_socket,0,sizeof(int)*max_clients);
	//set of socket descriptors  
    fd_set readfds;
	//create unix domain socket
	master_sock = socket(AF_UNIX,SOCK_STREAM,0);
	struct sockaddr_un addr;
	memset(&addr,0,sizeof(addr));
	addr.sun_path[0]=0;
	strcpy(addr.sun_path+1,srv_name);
	//strncpy(addr.sun_path,srv_name,sizeof(addr.sun_path)-1);
	addr.sun_family = AF_UNIX;
	int len = sizeof(sa_family_t)+strlen(srv_name)+1;
	//printf("path: %s, should be: %s \n",addr.sun_path+1,srv_name);
	if ((bind(master_sock, (struct sockaddr *)&addr, len)) == -1){
                fprintf(stderr, "Error on bind --> %s", strerror(errno));
                exit(EXIT_FAILURE);//exit(-1);return;
    }
	if (listen(master_sock, 3) < 0){   
        perror("listen");   
        exit(EXIT_FAILURE);   
    } 
    addrlen = strlen(addr.sun_path);//sizeof(addr);
    piThreadCreate(updaterThread);//initiating paralell loop to update values from mcu	
	if(debug==1){printf("socket binded and listening\n");}
	wiringPiSetup();
   if(wiringPiISR(ACOUSTIC_PIN, INT_EDGE_RISING, &acousticInterrupt) < 0){
		fprintf(stderr, "Unable to setup isr: %s\n", strerror(errno));
		//return 1;
	}
	targetMassPercentage = _COM;
	moveMass(targetMassPercentage);
	movePump(targetPumpPercentage);
	if(debug==1){printf("moving pump to %f, mass to %f\n",targetPumpPercentage,targetMassPercentage);}
    
    

	 while(1) {   
        //clear the socket set  
        FD_ZERO(&readfds);  
         
        //add master socket to set  
        FD_SET(master_sock, &readfds);   
        max_sd = master_sock;    
        //add child sockets to set  
        for ( i = 0 ; i < max_clients ; i++) {   
            //socket descriptor  
            sd = client_socket[i];   
                 
            //if valid socket descriptor then add to read list  
            if(sd > 0) {  
                FD_SET( sd , &readfds); 
                curr_cli = i+1; 
                //printf("adding client %d to read list",i); 
            } 
                 
            //highest file descriptor number, need it for the select function  
            if(sd > max_sd)   
                max_sd = sd;   
        } 
     
        //wait for an activity on one of the sockets , if timeout is NULL it will wait forever.   
		//int select(int nfds, fd_set *readfds, fd_set *writefds, fd_set *exceptfds, struct timeval *timeout);
        //printf("waiting for activity\n");
        activity = select( max_sd + 1 , &readfds , NULL , NULL , NULL);   
        if (activity == 0){ 
			//printf("no activity\n");    
            continue;      
        }   
        else{   
			//printf("activity\n");     
			//If something happened on the master socket ,  
			//then its an incoming connection  
			if (FD_ISSET(master_sock, &readfds)) {   
				if ((new_socket = accept(master_sock,(struct sockaddr *)&addr, (socklen_t*)&addrlen))<0) {   
					perror("accept error");   
					continue;  
				}   
				
				//add new socket to array of sockets  
				for (i = 0; i < curr_cli +1; i++){   
					//if position is empty  
					if( client_socket[i] == 0 ){   
						client_socket[i] = new_socket;   
						if(debug==1){printf("Adding to list of sockets as %d\n" , i);}
						break;   
					}   
				}   
			}   
				 
			//else its some IO operation on some other socket 
			//printf("%d clients\n",curr_cli);
			for (i = 0; i < curr_cli; i++){   
				sd = client_socket[i];   
				if(debug==1){printf("checking socket %d,%d\n",sd,i);}
				if (FD_ISSET( sd , &readfds)){  
					memset(buff,0,sizeof(buff)); 
					//Check if it was for closing , and read incoming message 
					if ((valread = read( sd , buff, sizeof(buff))) <= 0){   
						//Somebody disconnected
						//Close the socket and mark as 0 in list for reuse 
						if(debug==1){printf("closing client %d\n" , i); }
						close( sd );   
						client_socket[i] = 0;   
					}  
					else{  
						 if(debug==1){printf("\nparsing ");}
						 parse(buff,sd);//parse sent message, set msg_size, and message ptr to variable (message = &roll)
						 if(debug==1){printf("read %s",buff); }
						 if(debug==1){printf("parsed");}
					}   
					//printf(",%d\n",valread);
				}   
			}
        }     
    }   
         

}
