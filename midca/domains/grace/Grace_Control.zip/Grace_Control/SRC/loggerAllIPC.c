#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include "GliderFunIPC.h"

#define goto(x,y) (printf("\033[%d;%dH",x,y))
#define displayFloatAt(s,v,x,y) (printf("\033[%d;%dH%s: %.4f \033[K",x,y,s,v))
#define displayIntAt(s,v,x,y) (printf("\033[%d;%dH%s: %d \033[K",x,y,s,v))
#define displayCharAt(s,v,x,y) (printf("\033[%d;%dH%s: %c \033[K",x,y,s,v))
#define displayGPSAt(s,sig,lon,ew,lat,ns,x,y) (printf("\033[%d;%dH%s: %c,%f,%c,%f,%c\033[K",x,y,s,sig,lon,ew,lat,ns))
#define displayAt(s,x,y) (printf("\033[%d;%dH%s \033[K",x,y,s))

int debug = 0;
int display = 1;
int i=1,
	j=1;

void readBatt(FILE *fp_battery, int x) {
	int _internal_temperature = readInTemp();
	double _battery_voltage = readBattery();
	
	// DISPLAY THE CURRENT VOLTAGE AND TEMP IN CSV FORMAT
	fprintf(fp_battery,"%.2f,",_battery_voltage);
	fprintf(fp_battery,"%d ",_internal_temperature);
	
	// FLUSH THE FILE POINTER TO WRITE THE DATA TO THE FILE
	// THIS IS CRITICAL BECAUSE THE FILE IS TECHNICALLY NEVER CLOSED AND THEREFORE
	//	IF WE DO NOT FLUSH THE BUFFER THE DATA WILL NEVER GET WRITTEN
	fflush(fp_battery); 
	
	if (debug==1){
		printf("%.2f,",_battery_voltage);
		printf("%d",_internal_temperature);
	}
	if(debug==2||debug==3||display==1){
		displayFloatAt("BatterVoltage (V)",_battery_voltage,i++,1);//strlen("BatterVoltage (V): "));
		displayIntAt("inTemp (C)",_internal_temperature,i++,1);//strlen("inTemp (C): "));
    }
}

void readMainMCU(FILE *fp, int x, int sampleTime) {
//GPS
	char valid = readGPSValid();
	float lattitude = readLattitude();
	char ns_flag = readLatFlag();
	float longitude = readLongitude();
	char ew_flag = readLongFlag();

//IMU
	float yaw = readYaw();
	float pitch = readPitch();
	float roll = readRoll();
	float yawRate = readYawRate();
	float pitchRate = readPitchRate();
	float rollRate = readRollRate();	
	float IMU_temp = readIMUTemperature();
	float IMU_press = readIMUPressure();
	float accel_x = readAccelX();
	float accel_y = readAccelY();
	float accel_z = readAccelZ();
	
// Actuators
	//const float vol_range = 3.3; // DEPENDS ON OPERATING VOLTAGE OF MCU
	//const float mass_cm = 13.5; // DEPENDS ON ACTUATORS
	//const float pump_cm = 10.0; // DEPENDS ON ACTUATORS
	
	float m,p,s;
	p = readPumpPercentage();
	m = readMassPercentage();
	s = readServoAngle();
	
	
//Pressure
	float pressure = pressureToDepth(readPressure());
//Pressure average
	float pressure_avg = pressureToDepth(readAveragedPressure());
//Pressure average
	float pressure_filt = pressureToDepth(readFilteredPressure());
	float translatedDepth =-0.15*sin(pitch*M_PI/180)-0.15*cos(pitch*M_PI/180)+pressure_filt;
//Time
	char month[5];
	char year[5];
	char day[5];
	char hour[5];
	char min[5];
	char sec[5];
	

   long gps_time = readGPSTime();
	
	time_t t = gps_time;//time(NULL);
	struct tm tm = *gmtime(&t);
	sprintf(year, "%d", tm.tm_year+1900);
	sprintf(month,"%d",tm.tm_mon+1);
	sprintf(day,"%d",tm.tm_mday);
	sprintf(hour,"%d",tm.tm_hour);
	sprintf(min,"%d",tm.tm_min);
	sprintf(sec,"%d",tm.tm_sec);
    //time_t now = timegm(&tm);
	// DISPLAY IN CSV FORMAT
	fprintf(fp,"%s-%s-%s_%s:%s:%s,",month,day,year,hour,min,sec);
	fprintf(fp,"%c,",valid);
	fprintf(fp,"%f,%c,%f,%c,",longitude,ew_flag,lattitude,ns_flag);
	
	fprintf(fp,"%.4f,",pressure);
	fprintf(fp,"%.4f,",pressure_avg);
	fprintf(fp,"%.4f,",pressure_filt);
	fprintf(fp,"%.4f,",translatedDepth);
	fprintf(fp,"%.4f,",IMU_press);
	fprintf(fp,"%.4f,%.4f,%.4f,",yaw,pitch,roll);
	fprintf(fp,"%.4f,%.4f,%.4f,",yawRate,pitchRate,rollRate);
	fprintf(fp,"%.4f,%.4f,%.4f,",accel_x,accel_y,accel_z);
	fprintf(fp,"%.2f,",IMU_temp);
	
	fprintf(fp,"%.2f,",m);
	fprintf(fp,"%.2f,",p);
	fprintf(fp,"%.1f,",s);
	
	
	// FLUSH THE FILE POINTER TO WRITE THE DATA TO THE FILE
	// THIS IS CRITICAL BECAUSE THE FILE IS TECHNICALLY NEVER CLOSED AND THEREFORE
	//	IF WE DO NOT FLUSH THE BUFFER THE DATA WILL NEVER GET WRITTEN
	fflush(fp); 


	if (debug==1){
		printf("%s-%s-%s_%s:%s:%s,",month,day,year,hour,min,sec);
		printf("%c,",valid);
		printf("%f,%c,%f,%c,",longitude,ew_flag,lattitude,ns_flag);
		
		printf("%.4f,",pressure);
		
		printf("%f,%f,%f,",roll,pitch,yaw);
		
		printf("%.2f,",m);
		printf("%.2f,",p);
		printf("%.1f,",s);
	}
	if(debug==2||debug==3||display==1){
		char date[50];
		sprintf(date,"Current UTC Time (mdy,time): %s-%s-%s, %s:%s:%s,",month,day,year,hour,min,sec);
		displayAt(date,i++,0);
		printf("\033[%d;%dHRAW GPS Time: %lu \033[K",i++,1,gps_time);
		displayGPSAt("GPS",valid,longitude,ew_flag,lattitude,ns_flag,i++,1);
		displayFloatAt("Depth (m)",pressure,i++,1);
		displayFloatAt("Filtered Depth (m)",pressure_filt,i++,1);
		displayFloatAt("Filter Translated Depth (m)",translatedDepth,i++,1);
		displayFloatAt("Internal Pressure (kPa)",IMU_press,i++,1);
		displayFloatAt("Yaw",yaw,i++,1);
		displayFloatAt("Yaw Rate",yawRate,i++,1);
		displayFloatAt("Pitch",pitch,i++,1);//strlen("Pitch: "));
		displayFloatAt("Pitch Rate",pitchRate,i++,1);
		displayFloatAt("Roll",roll,i++,1);//strlen(("Roll: "));
		displayFloatAt("Roll Rate",rollRate,i++,1);
		displayFloatAt("Acceleration X",accel_x,i++,1);
		displayFloatAt("Acceleration Y",accel_y,i++,1);
		displayFloatAt("Acceleration Z",accel_z,i++,1);
		displayFloatAt("Mass Pos (%)",m,i++,1);
		displayFloatAt("Pump Pos (%)",p/pump_remap_constant,i++,1);
		displayFloatAt("Servo angle",s,i++,1);
		displayFloatAt("IMU Temperature",IMU_temp,i++,1);
    }
	
}
void readEnvSensorMCU(FILE *fp, int x, int sampleTime) {
//DO 
	// concentration
	float DOCON=readDOCON();
	// out temp
	float outTemp = readDOTEMP();
	// partial pressure
	float DOPPS = readDOPPS();
	// saturation
	float DOSAT = readDOSAT();
	
	float c1 = readChlorophylCy(); 
	//m = m/vol_range*mass_cm;
	float c2 =readAlgaeCy(); 
	//usleep(sampleTime);
//PAR	
	float p = readPar(); 
	
	fprintf(fp,",%f,%f,%f,%f",outTemp,DOPPS,DOCON,DOSAT);
	fprintf(fp,",%f,%f,%f",c1,c2,p);
	// FLUSH THE FILE POINTER TO WRITE THE DATA TO THE FILE
	// THIS IS CRITICAL BECAUSE THE FILE IS TECHNICALLY NEVER CLOSED AND THEREFORE
	//	IF WE DO NOT FLUSH THE BUFFER THE DATA WILL NEVER GET WRITTEN
	fflush(fp); 
	if (debug==1){
		printf(",%f,%f,%f,%f",outTemp,DOPPS,DOCON,DOSAT);
		printf(",%f,%f,%f",c1,c2,p);
	}
	if(debug==2||debug==3||display==1){
		displayFloatAt("outTemp(C)",outTemp,i++,1);//strlen("outTemp(C): "));
		displayFloatAt("DO Partial Pressure",DOPPS,i++,1);//strlen("DO Partial Pressure: "));
		displayFloatAt("DO Concentration",DOCON,i++,1);//strlen("DO Concentration: "));
		displayFloatAt("DO Saturation",DOSAT,i++,1);//strlen("DO Saturation: "));
		displayFloatAt("Cyclops1",c1,i++,1);//strlen("Cyclops1: "));
		displayFloatAt("Cyclops2",c2,i++,1);//strlen("Cyclops2: "));
		displayFloatAt("PAR",p,i++,1);//strlen("PAR: "));
    }
	
}

int main(int argc, char **argv){
	int sampleTime = 300000;
	char customFileName[100] ="";
	for (int i = 0;i<argc;i++){
			if(argv[i][0]=='-'){
				if(strcmp(argv[i]+1,"ts")==0){
					sampleTime = (int)(atof(argv[1])*1000000.0);
					if (sampleTime <= 0){
						printf("only positive intergers allowed.\n");
						sampleTime = 500000;
					}
				}	
				else if(strcmp(argv[i]+1,"dbg")==0)
					debug = atoi(argv[i+1]);
				else if(strcmp(argv[i]+1,"display")==0)
					display = atoi(argv[i+1]);	
				else if(strcmp(argv[i]+1,"file")==0)
					strcpy(customFileName,argv[i+1]);	
			}
	}
	if(debug==2||debug==3||display==1){
		printf("\n\033[H\033[J");
		goto(1,1);
		displayFloatAt("Sample interval (sec)",sampleTime/1000000.0,1,1);
    }
    else{
	   printf("Sample interval - %f seconds\n",sampleTime/1000000.0 );
    }
    if (initIPC()<0){
		printf("Could not connect to dataPipe.c");
		exit(-1);
	}
	logProgramStart(argc,argv);
    //~ initMain(0x32);
	//~ initBattMon(0x18);
	//~ initEnvSensors(0x39);
	int x= 0;//wiringPiI2CSetup(0x32); //mainMCU 
	int y = 0;//wiringPiI2CSetup(0x39); //envSenseMCU
	int z = 0;//wiringPiI2CSetup(0x18);  //battMon
	
	//int RTC = wiringPiI2CSetup(0x68);

	FILE *fp;
	char filename[35];
	char filepath[50];
	char year[5];
	char month[5];
	char day[5];
	char hour[5];
	char min[5];
	char sec[5];
	
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);
	if(readGPSValid()=='A'){
		t = readGPSTime();
		tm = *gmtime(&t);
	}
    
	// STORE CURRENT TIME IN VARIOUS ARRAYS BASED ON REAL TIME CLOCK TIME VALUE
	sprintf(month, "%d", tm.tm_mon+1);
	sprintf(day, "%d", tm.tm_mday);
	sprintf(year, "%d", tm.tm_year+1900);
	sprintf(hour, "%d", tm.tm_hour);
	sprintf(min, "%d", tm.tm_min);
	sprintf(sec, "%d", tm.tm_sec); 

	strcpy(filename,"Datalog-");
	strcat(filename,year);
	strcat(filename,"-");
	strcat(filename,month);
	strcat(filename,"-");
	strcat(filename,day);
	strcat(filename,"_");
	strcat(filename,hour);
	strcat(filename,":");
	strcat(filename,min);
	strcat(filename,":");
	strcat(filename,sec);
	strcpy(filepath,"./DATALOG/");
	if(debug!=0){strcpy(filename,"test");}
	if (strcmp(customFileName,"")!=0){strcpy(filename,customFileName);}
	strcat(filepath,filename);
	strcat(filepath,".csv");
	//printf(filepath);
	// CREATE A FILE NAME CONSISTING OF "Datalog-MONTH-DAY_HOUR:MIN:SECOND
	//	AND STORE IT IN A FOLDER IN THE CURRENT DIRECTORY CALLED "DATALOG"
	// OPEN THE FILE WE HAVE JUST CREATED FOR WRITING
	fp = fopen(filepath, "w");
	if (fp == NULL)
	{
		printf("Null File Pointer acoustic\n");
		return 0;
	}
	


	// CSV HEADER
	fprintf(fp,"Current Time,Valid Signal,Longitude,EW,Latitude,NS,Depth (m),Depth Averaged (m),Depth Filtered (m),Filter Translated Depth (m),Internal Pressure (kPa),Yaw,Pitch,Roll,Yaw Rate, Pitch Rate, Roll Rate, X acelleration, Y accelleration, Z accelleration, IMU Temperature (C), MassVal (%%), PumpVal(%%),ServoPos ,BatterVoltage (V),inTemp (C),outTemp,DO Partial Pressure,DO Concentration,DO Saturation,Cyclops1,Cyclops2,PAR\n");
	//fprintf(fp,"Pressure Data (V),Pressure Average,Pressure Filterd,Yaw,Pitch,Roll, MassVal (%) ,, PumpVal(%)ServoPos ,BatterVoltage (V),inTemp (C),outTemp,DO Partial Pressure,DO Concentration,DO Saturation,Cyclops1,Cyclops2,PAR\n");

	
	if(debug==1){
		printf("Current Time,Valid Signal,Longitude,EW,Latitude,NS,Pressure Data (V),Pressure Average,Yaw,Pitch,Roll, PumpVal(cm), MassVal (cm) ,ServoPos ,BatterVoltage (V),inTemp (C),outTemp,DO Partial Pressure,DO Concentration,DO Saturation,Cyclops1,Cyclops2,PAR\n");
	}
	// RUN THIS PROCESS IN THE BACKGROUND UNTIL WE KILL IT
	//printf("%d,%d,%d\n",x,y,z);
	if(debug==2||debug==3||display==1){
		//goto(2,0);
		i=2;
    }
	int delay = 1000;
	while(1){
		readMainMCU(fp,x,delay);
		//usleep(delay);
		readBatt(fp,z);
		//usleep(delay);
		readEnvSensorMCU(fp,y,delay);
		//usleep(delay); 
		fprintf(fp,"\n");
		fflush(fp);
		if (debug==1){
			printf("\n");
		}
		if(debug==2||debug==3||display==1){
			i=2;
		}
		usleep(sampleTime);
	}
	return 0;
}
