#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include <math.h>
#include <time.h>
#include "GliderFunIPC.h"
#define sgn(v) ((v<0)?-1:(v>0))

float pitch;
float surfacePressure = 0;
float saturationPressure = 3.28;
float COB;
float COM;
//~ float pressureToDepth(double pressure){
	 //~ return (pressure-.521131)/(0.04) * 0.7038;
 //~ }
 

void singleDive(double targetDepth, double massForward, double massBackward){
	moveMass(massForward);
	usleep(300000);
	movePump(0.01);
	//float currentPressure = readFilteredPressure();
	usleep(300000);
	float currentDepth = pressureToDepth(readFilteredPressure());
	while(currentDepth<=targetDepth){
		//~ if(fabsf(currentPressure-targetPressure)<=dist){
			//~ movePump(saturate(COB+gain*(currentPressure-targetPressure),0.0,99.9));
		//~ }
		float dumdumb = pressureToDepth(readFilteredPressure());
		if (dumdumb<5)
			currentDepth = dumdumb;
		
		usleep(300000);
		//printf("%f\n",currentDepth);
	}
	movePump(99.9);
	usleep(30000);
	moveMass(massBackward);
}

int main(int argc, char **argv){
	if (initIPC()<=0){
		printf("Could not connect to dataPipe.c\n");
		exit(-1);
	}
	logProgramStart(argc,argv);
	//surfacePressure = calibrateSurfacePressure(10);
	surfacePressure = readSurfacePressure();
	printf("Avg. surface depth = %f\n", pressureToDepth(surfacePressure));
	
	float depth = 0;
	float massF = 50.0;
	float massB = 50.0;
	float depthTop = pressureToDepth(surfacePressure) + pressureOffset;
	
	int n = 1;
	COM = 50;
	COB = 50;
	for (int i = 0;i<argc;i++){
			if(argv[i][0]=='-'){
				if(strcmp(argv[i]+1,"COB")==0)
					COB = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"COM")==0)
					COM = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"D")==0)
					depth = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"DT")==0)
					depthTop = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"MassF")==0)
					massF = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"MassB")==0)
					massB = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"n")==0)
					n = atoi(argv[i+1]);	
			}
	}
	
	if (depthTop < pressureToDepth(surfacePressure) + 0.03) {
		printf("Specified top depth is less than computed surface depth.\n");
		exit(-1);
	}
	
	printf("dive params: \n \tCOB-%f\n \tCOM-%f\n \tDepth-%f\n \tDepth top-%f\n \tMF-%f\n \tMB-%f\n \tn-%d\n",COB,COM,depth,depthTop,massF,massB,n);
	
	
	//singleDive(depthToPressure(depth),massF,massB);
	for (int i = 0; i < n; i++) {
		printf("Dive %d of %d\n",i+1,n);
		singleDive((double)depth,(double)massF,(double)massB);
		usleep(30000);
		
		float dumdumb = pressureToDepth(readFilteredPressure());
		float currentDepth;
		while (dumdumb>5 || dumdumb<=0){
			usleep(300000);
			dumdumb = pressureToDepth(readFilteredPressure());
		}
		printf("current dumbdumb = %f\n",dumdumb);
		currentDepth = dumdumb;
		while (currentDepth > depthTop) {
			usleep(300000);
			float dumdumb = pressureToDepth(readFilteredPressure());
			if (dumdumb<5 && dumdumb>0)
				currentDepth = dumdumb;

			printf("current depth = %f\n",currentDepth);
		}
	}
}
