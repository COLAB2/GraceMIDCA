#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include <math.h>
#include <time.h>
#include "GliderFunIPC.h"
#define sgn(v) ((v<0)?-1:(v>0))

int main(int argc, char **argv){
	if (initIPC()<=0){
		printf("Could not connect to dataPipe.c\n");
		exit(-1);
	}
	logProgramStart(argc,argv);
	float target = 0;
	for (int i = 0;i<argc;i++){
			if(argv[i][0]=='-'){
				if(strcmp(argv[i]+1,"target")==0)
					target = atof(argv[i+1]);	
			}
	}
	while(1){
		sleep(1);
		float angle = readYaw();
		if(fabsf(angle-target)>2){
			yawComp(angle,target);
			printf("bearing = %f\n", angle-target);
		}
	}
}
