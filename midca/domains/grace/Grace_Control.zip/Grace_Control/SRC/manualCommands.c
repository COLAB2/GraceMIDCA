#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include "GliderFunIPC.h"

int main(){
	char buff[1024];
	int sock, rc;
    sock = initIPC();
	if(sock<0){
		return -1;
	}  
	else{
		printf("connection successful\n\n");
		int kill = 0;
		while(kill!=1){
			memset(buff,0,sizeof(buff));
			scanf("%s",buff);
			if(strcmp(buff,"exit")==0||strcmp(buff,"kill")==0){
				kill=1;
			}
			//rc=write(sock,buff,strlen(buff));
			rc = send(sock,buff,strlen(buff),0);
			if (rc<0){
				perror("write");
			}
			else{
				memset(buff,0,sizeof(buff));
				printf("reading\n");
				read(sock,buff,sizeof(buff));
				printf("%s\n\n",buff);
			}
		}
	} 
}
