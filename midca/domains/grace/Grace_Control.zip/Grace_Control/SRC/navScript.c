#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include <math.h>
#include <time.h>
#include "GliderFunIPC.h"
#define sgn(v) ((v<0)?-1:(v>0))
int parseWaypointsFile(char* fName, float* arr){
	int points = 0;
	FILE *fp;
	char* line = NULL;
	char* id = NULL;
	char* coord =NULL;
	size_t len = 0;
	fp = fopen(fName,"r");
	if (fp==NULL){
		return 0;
	}
	getline(&line,&len,fp);
	if(strncmp(line,"lat",3)==0){
		
	}
	while(getline(&line,&len,fp)!=-1){
		
	}
	return points;
}
int main(int argc, char **argv){
	if (initIPC()<=0){
		printf("Could not connect to dataPipe.c\n");
		exit(-1);
	}
	logProgramStart(argc,argv);
	
	
	float longi = 0;
	float lat = 0; 
	float swimDist = 20;
	float targetReached = 10;
    float surfaceWait = 5;
	int waitForResponse = 1;

	float wayPoints[100] = {0};
	int lonSet = 0;
	int latSet = 0;
	int waypointsSet = 0;
	char cmd [1024] = "./PID2depthDive ";
	char send [1024];
	for (int i = 1;i<argc;i++){
			if(argv[i][0]=='-'){
				if(strcmp(argv[i]+1,"long")==0){
					longi = atof(argv[i+1]);
					lonSet = 1;
				}
				else if(strcmp(argv[i]+1,"lat")==0){
					lat = atof(argv[i+1]);
					latSet = 1;	
				}
				else if(strcmp(argv[i]+1,"targetReached")==0)
					targetReached = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"swimDist")==0)
					swimDist = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"navFile")==0){
					int waypointsSet = parseWaypointsFile(argv[i+1],wayPoints);
				}
				else if(strcmp(argv[i]+1,"waitForReponse")==0)
					waitForResponse = atoi(argv[i+1]);	
				else if(strcmp(argv[i]+1,"surfaceWait")==0)
					surfaceWait = atof(argv[i+1]);		
			}
			strcat(cmd,argv[i]);
			strcat(cmd," ");
	}
	int diveResponse = 0;
     if (latSet==0 || lonSet==0 ){
		if(waypointsSet==0){
			printf("no destination set\n");
			exit(-1);
		}
	}
	//~ char temp[100];
	//~ sprintf(temp,"python xbeeSender.py surface wait time = %f\n",surfaceWait);
	//~ system(temp);
	
	float bearing = readYaw();
	float distance = 0;
	char valid = readGPSValid();
	if(valid=='A'){
			bearing = GPS_GetBearingToTarget(lat,longi);
			distance = GPS_GetDistanceToTarget(lat,longi);
			printf("bearing = %f\n", bearing);
			printf("distance = %f\n", distance);
	}
	else{printf("GPS not available");}
	while(distance>swimDist){
		time_t begin = time(NULL);
		while(diveResponse != 1 || (float)difftime(time(NULL),begin) < surfaceWait ){		
			if (waitForResponse == 1){
				system("python xbeeSender.py $%IND%$");
				sleep(1);
				FILE *fp = fopen("Next_Dive_GO","r");
				diveResponse = 0;
				if (fp != NULL){
					char temp = fgetc(fp);
					if(temp == '1'){
						system("rm Next_Dive_GO");
						diveResponse = 1;
					}
					fclose(fp);
				}
			}
			else{
				diveResponse = 1;
			}
			bearing = GPS_GetBearingToTarget(lat,longi);
			distance = GPS_GetDistanceToTarget(lat,longi);
			char tmpMsg[100] = {0};
			sprintf(tmpMsg,"python xbeeSender.py bearing=%f\n", bearing);
			system(tmpMsg);
			memset(tmpMsg,0,sizeof(tmpMsg));
			sprintf(tmpMsg,"python xbeeSender.py distance=%f\n", distance);
			system(tmpMsg);
			memset(tmpMsg,0,sizeof(tmpMsg));
			sprintf(tmpMsg,"python xbeeSender.py current angle=%f\n", readYaw());
			system(tmpMsg);
			//~ memset(tmpMsg,0,sizeof(tmpMsg));
			//~ sprintf(tmpMsg,"python xbeeSender.py difftime =%f\n", difftime(time(NULL),begin));
			//~ system(tmpMsg);
			//~ memset(tmpMsg,0,sizeof(tmpMsg));
			//~ sprintf(tmpMsg,"python xbeeSender.py difftimeFLAG =%d\n", diveResponse != 1 || (float)difftime(time(NULL),begin) < surfaceWait);
			//~ system(tmpMsg);
			
			float angle = readYaw();
			yawCompFlap(angle,bearing,45,0.5);
			//~ if(fabsf(angle-bearing)>5){
				//~ yawComp(angle,bearing);
			//~ }
		}
		diveResponse = 0;
		valid = readGPSValid();
		if(valid=='A'){
			char temp[100] = {0};
			bearing = GPS_GetBearingToTarget(lat,longi);
			distance = GPS_GetDistanceToTarget(lat,longi);
            //printf("(tlat,tlongi)=(%f,%f)",lat,longi);
			//printf("(lat,longi)=(%f,%f)",readLattitude(),readLongitude());
			printf("bearing = %f\n", bearing);
			//sprintf(temp,"-targetYaw %f\n", bearing);
			sprintf(temp,"-targetYaw %f", bearing);
			sprintf(send,"%s", cmd);
			printf("distance = %f\n", distance);
			strcat(send,temp);
		}
		float angle = readYaw();
		//if(swimDistance>0 && fabsf(angle-bearing)>5){oscillateServo(angle-bearing,saturate(5*distance,0,45),.75);}
		if(fabsf(angle-bearing)>2){
			yawComp(angle,bearing);
			printf("yaw error = %f\n", angle-bearing);
		}
		if(valid=='A' && distance>swimDist){
			printf("bearing = %f\n", bearing);
			printf("angle = %f\n", angle);
			printf("distance = %f\n", distance);
			system("python xbeeSender.py starting dive program\n");
			system(send);
			system("python xbeeSender.py call complete\n");
			printf("%s \n",send);
		}
		//char temp[100] = {0};
		//sprintf(temp,"-targetYaw %f\n", bearing);
		//sprintf(send,"python xbeeSender.py %s", cmd);
		//printf("distance = %f\n", distance);
		//strcat(send,temp);
		//system(send);
	}
    moveMass(_COM);
	movePump(99.9);
	while(distance>targetReached){
		float angle = readYaw();
		if(readGPSValid()=='A'){
			bearing = GPS_GetBearingToTarget(lat,longi);
			distance = GPS_GetDistanceToTarget(lat,longi);
			printf("bearing = %f\n", bearing);
			printf("distance = %f\n", distance);
			char tmpMsg[100] = {0};
			sprintf(tmpMsg,"python xbeeSender.py bearing=%f\n", bearing);
			system(tmpMsg);
			memset(tmpMsg,0,sizeof(tmpMsg));
			sprintf(tmpMsg,"python xbeeSender.py distance=%f\n", distance);
			system(tmpMsg);
			memset(tmpMsg,0,sizeof(tmpMsg));
			sprintf(tmpMsg,"python xbeeSender.py current angle=%f\n", angle);
			system(tmpMsg);
			sleep(3);
		}
		angle = readYaw();
		//if(fabsf(angle-bearing)>5){oscillateServo(angle-bearing,saturate(5*distance,0,45),.75);}
		yawCompFlap(angle,bearing,45,0.5);
	}
	moveServo(0);
	moveMass(_COM);
	system("python xbeeSender.py target reached\n");
}
