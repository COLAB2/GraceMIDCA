#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include "GliderFunIPC.h"
#include "GliderDefinitions.h"
int sock;

void sendReadMeassage(char* mcu, char varToRead){
	char msg[50]={0};
	sprintf(msg,"R,%s,%c\n",mcu,varToRead);
	printf("%s\n",msg);
	send(sock,msg,strlen(msg),0);
	
}

int main(){
	char buff[1024];
	sock = initIPC();
	if(sock < 0){
		perror("socket error");
		exit(-1);
	} 
	else{
		printf("connection successful\n\n");
		int kill = 0;
		struct timeval to;
		to.tv_sec = 1;
		to.tv_usec = 0;
		setsockopt(sock,SOL_SOCKET,SO_RCVTIMEO,(const char*)&to,sizeof(to));
		int state = 0;
		while(kill!=1){
			memset(buff,0,sizeof(buff));
			scanf("%s",buff);
			if(strcmp(buff,"exit")==0||strcmp(buff,"kill")==0){
				kill=1;
			}
			char s[100]= {0};
			int i = atoi(buff);
			float fl_var;
			long lng_var;
			char chr_var;
			if(i<mmcu_varnum){
				sprintf(s,"R,MAIN,%d,-s\n",i);
				//sprintf(s,"R,MAIN,%d",i);
			}
			if (i >= mmcu_varnum){
				sprintf(s,"R,SENSOR,%d,-s\n",i%mmcu_varnum);
				//sprintf(s,"R,SENSOR,%d",i%mmcu_varnum);
			}
			if (i >= mmcu_varnum+emcu_varnum){
				sprintf(s,"R,BATTERY,%d,-s\n",i%(mmcu_varnum+emcu_varnum));
				//sprintf(s,"R,BATTERY,%d",i%(mmcu_varnum+emcu_varnum));
			}
			send(sock,s,strlen(s),0);
			printf("sent: %s\n",s);
			memset(buff,0,sizeof(buff));
			if ( i<0){
				state=(1+state)%4;
			}
			if(state == 0){
				read(sock,buff,sizeof(buff));
				printf("recieved string: %s\n",buff);
			}
			if(state == 1){
				read(sock,buff,sizeof(fl_var));
				memcpy(&fl_var,buff,sizeof(buff));
				printf("recieved float: %f\n",fl_var);
			}
			if(state == 2){
				read(sock,&lng_var,sizeof(lng_var));
				printf("recieved long: %lu\n",lng_var);
			}
			if(state == 3){
				read(sock,&chr_var,sizeof(chr_var));
				printf("recieved char: %c\n",chr_var);
			}
		}
	} 
}
