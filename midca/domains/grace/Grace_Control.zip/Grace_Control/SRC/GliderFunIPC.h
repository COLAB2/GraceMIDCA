/*  GliderFunIPC.h
 *  This program has a function that sets up interprocess communication 
 *  to access the dataPipe.c program and functions that retieve data and 
 *  sends robot controls.
 * */
#pragma once
#ifndef _IPC_CONTROL
#define _IPC_CONTROL

#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <math.h>
#include "GliderDefinitions.h"

#define PI 3.14159
char *srv = SERVER_NAME;
int sock, rc;
const char *mainMCU=MAIN_MCU_TAG; 
const char *eSensorMCU=SENSOR_MCU_TAG;
const char *battMon=BATT_MON_TAG;
const char *acousticMCU=ACOUSTIC_RECIEVER_MCU_TAG;

//Functions Declaratins
int initIPC();
void setSocketTimeout(float timeout);
void setUpdateRate(char* TAG, char val, float rate);

void readGPS(float* dataArray);
float readLattitude();
float readLongitude();
long readGPSTime();
char readLatFlag();
char readLongFlag();
char readGPSValid();
float GPS_GetDistanceToTarget(float targetLatitude, float targetLongitude);
float GPS_GetBearingToTarget(float targetLatitude, float targetLongitude);

void readIMU(float* dataArray);
float readYaw();
float readPitch();
float readRoll();
float readYawRate();
float readPitchRate();
float readRollRate();
float readAccelX();
float readAccelY();
float readAccelZ();
float readIMUPressure();
float readIMUTemperature();
void TareIMU();
void SaveIMU();
void SetHeadingIMU(int mode);
float yawComp(float yaw, float yaw_d);
float yawCompLowGain(float yaw, float yaw_d);
float yawCompFlap(float yaw, float yaw_d,float amp, float flapTime);

void readActuators(float* dataArray);
float readMassPos();
float readMassVoltage();
float readMassPercentage();
float readPumpPos();
float readPumpVoltage();
float readPumpPercentage();
float readServoAngle();

float readPressure();
float readAveragedPressure();
float readFilteredPressure();
float readSurfacePressure();
float pressureToDepth(float pressure);
float calibrateSurfacePressure(int samples); 
//float depthToPressure(float depth);									

void _move(char actuator, char *pos);
void movePump(double percentage);
void stopPump();
void moveMass(double percentage);
void stopMass();
void moveServo(int fixed_int);
void setPropeller(int speed);
void stopProppeller();					  
void stopServo();
void oscillateServo(double bias, double amp, float time_float);
void oscillateServo2(int high_int, int low_int, float time_float);

double readBattery();
int readInTemp();

float readDOCON();
float readDOTEMP();
float readDOPPS();
float readDOSAT();
float readPar();
float readPar2();
float readAlgaeCy();
float readChlorophylCy();
void readCyclops12(float* arr);

float readFloatVar(const char* mcu,char chartoSend);
long  readLongVar(const char* mcu,char chartoSend);
char  readCharVar(const char* mcu,char chartoSend);
int logProgramStart(int argc, char **argv);
//Functions Definitions
int initIPC(){
	struct sockaddr_un addr;
	sock = socket(AF_UNIX,SOCK_STREAM,0);
	if(sock < 0){
		perror("socket error");
	}
	memset(&addr,0,sizeof(addr));
	addr.sun_family = AF_UNIX;
	if (*srv == '\0'){
		*addr.sun_path = '\0';
		strncpy(addr.sun_path+1,srv+1,sizeof(addr.sun_path)-2);
	}
	else{
		addr.sun_path[0]=0;
		strcpy(addr.sun_path+1,srv);
	}
	int len =sizeof(struct sockaddr_un)+strlen(srv)+1;
	len =sizeof(sa_family_t)+strlen(srv)+1;
	if(connect(sock,(struct sockaddr *) &addr, len)<0){
		close(sock);
		perror("connection error");
		return -1;
		//try running pipe program and reconnect
		//~ if(connect(sock,(struct sockaddr *) &addr, len)<0){
			//~ close(sock);
			//~ return -1;
		//~ } 
	}  
	struct timeval to;
	to.tv_sec = 1;
	to.tv_usec = 0;
	setsockopt(sock,SOL_SOCKET,SO_RCVTIMEO,(const char*)&to,sizeof(to));
	calibrate();
	return sock;
}
void setSocketTimeout(float timeout){
	struct timeval to;
	to.tv_sec = (int)timeout;
	to.tv_usec = (long)(fmod(timeout,1.0)*1e6);
	setsockopt(sock,SOL_SOCKET,SO_RCVTIMEO,(const char*)&to,sizeof(to));
};

void setUpdateRate(char* TAG, char val, float rate){
	char msg[40]={0};
	sprintf(msg,"SET,%s,%f,%c\n",TAG,rate,val);
	send(sock,msg,strlen(msg),0);
};

//helper functions
float readFloatVar(const char* mcu, char charToSend){
	char s[50] = {0};
	char data[20];
	sprintf(s,"R,%s,%d,-s\n",mcu,(int)charToSend);
	//sprintf(s,"R,%s,%d",mcu,(int)charToSend);
	send(sock,s,strlen(s),0);
	read(sock,&data,sizeof(data));//read(sock,&data,READ_FLOAT);
	return atof(data);
};
long readLongVar(const char* mcu, char charToSend){
	char data[20];
	char s[50] = {0};
	sprintf(s,"R,%s,%d,-s\n",mcu,(int)charToSend);
	//sprintf(s,"R,%s,%d",mcu,(int)charToSend);
	send(sock,s,strlen(s),0);
	read(sock,&data,sizeof(data));//read(sock,&data,READ_LONG);
	return atol(data);
};
char readCharVar(const char* mcu, char charToSend){
	char data;
	char s[50] = {0};
	sprintf(s,"R,%s,%d,-s\n",mcu,(int)charToSend);
	//sprintf(s,"R,%s,%d",mcu,(int)charToSend);
	send(sock,s,strlen(s),0);
	read(sock,&data,READ_CHAR);
	return data;
};
void _move(char actuator, char *pos){
	char msg[20]={0};
	sprintf(msg,"MV,%c,%s\n",actuator,pos);
	send(sock,msg,strlen(msg),0);
};

int logProgramStart(int argc, char **argv){
	#include <time.h>
	char msg[1024] = "->";
	if(argc>0){
		for (int i = 0;i<argc;i++){strcat(msg,argv[i]);strcat(msg,", ");}
	}
	strcat(msg,"\n");
	FILE *fp;
	char filename[1024];
	char filepath[50];
	char year[5];
	char month[5];
	char day[5];
	char hour[5];
	char min[5];
	char sec[5];
	
	time_t t = readGPSTime();
	struct tm tm = *gmtime(&t);
	// STORE CURRENT TIME IN VARIOUS ARRAYS BASED ON REAL TIME CLOCK TIME VALUE
	sprintf(month, "%d", tm.tm_mon+1);
	sprintf(day, "%d", tm.tm_mday);
	sprintf(year, "%d", tm.tm_year+1900);
	sprintf(hour, "%d", tm.tm_hour);
	sprintf(min, "%d", tm.tm_min);
	sprintf(sec, "%d", tm.tm_sec); 

	strcpy(filename,"logging-");
	strcat(filename,year);
	strcat(filename,"-");
	strcat(filename,month);
	strcat(filename,"-");
	strcat(filename,day);
	strcat(filename,"_");
	strcat(filename,hour);
	strcat(filename,":");
	strcat(filename,min);
	strcat(filename,":");
	strcat(filename,sec);
	t = time(NULL);
	tm = *localtime(&t);
	sprintf(month, "%d", tm.tm_mon+1);
	sprintf(day, "%d", tm.tm_mday);
	sprintf(year, ",%d", tm.tm_year+1900);
	sprintf(hour, "%d", tm.tm_hour);
	sprintf(min, "%d", tm.tm_min);
	sprintf(sec, "%d", tm.tm_sec); 
	strcat(filename,year);
	strcat(filename,"-");
	strcat(filename,month);
	strcat(filename,"-");
	strcat(filename,day);
	strcat(filename,"_");
	strcat(filename,hour);
	strcat(filename,":");
	strcat(filename,min);
	strcat(filename,":");
	strcat(filename,sec);
	strcpy(filepath,"./DATALOG/");
	strcat(filepath,"programLog");
	strcat(filepath,".txt");
	fp = fopen(filepath, "a");
	if (fp == NULL){
		printf("File not opend\n");
		return -1;
	}
	fprintf(fp,filename);
	fprintf(fp,msg);
	//fprintf(fp,"\n");
	fclose(fp);
	return 1;
}

//pressure sensor
float calibrateSurfacePressure(int samples) {
	float press = 0;
	for (int i = 0; i < samples; i++) {
		usleep(10000);
		press += readFilteredPressure();
	}
	press = press/samples;
	char msg[80]={0};
	sprintf(msg,"SET,%s,%d,%f\n",RPI_TAG,SURFACE_PRESSURE,press);
	send(sock,msg,strlen(msg),0);
	return press;
};

float pressureToDepth(float pressure){
	 return (pressure-readSurfacePressure())/(0.04) * 0.7038;
};
 
float readPressure(){
	return readFloatVar(mainMCU, PRESSURE_READ);
};
float readAveragedPressure(){
	return readFloatVar(mainMCU, PRESSURE_AVG_READ);
};
float readFilteredPressure(){
	return readFloatVar(mainMCU, PRESSURE_BWF_READ);
};
float readSurfacePressure(){
	return readFloatVar(RPI_TAG, SURFACE_PRESSURE);
};

 //float pressureToDepth(float pressure){
//	 return (pressure-.529)/(0.04) * 0.7038;
// };
 
// float depthToPressure(float depth){
//	 return depth*(0.04)/0.7038+.529;
 //};
 
// battey monitor chip functoions
double readBattery() {
	return readFloatVar(battMon, BATT_READ);					 
};

int readInTemp() {
	return (int)readFloatVar(battMon, BATT_TEMP_READ);					  
};


//GPS Functions
void readGPS(float* dataArray) {
	float lattitude = readFloatVar(mainMCU, GPS_LAT_READ);
	float longitude= readFloatVar(mainMCU, GPS_LONG_READ);
    dataArray[0]=lattitude;
	dataArray[1]=longitude;
};
float readLattitude(){
	return readFloatVar(mainMCU, GPS_LAT_READ);
};
float readLongitude(){
	return readFloatVar(mainMCU, GPS_LONG_READ);
};
char readGPSValid(){
	return readCharVar(mainMCU, GPS_VALID_READ);	  
};
char readLongFlag(){
   return readCharVar(mainMCU, GPS_EW_FLAG_READ);		
};
char readLatFlag(){
   return readCharVar(mainMCU, GPS_NS_FLAG_READ);			
};
long readGPSTime(){
	return readLongVar(mainMCU, GPS_TIME_READ);
};
long readGPSDate(){
	return readLongVar(mainMCU, GPS_DATE_READ);
};
//~ long getGPSEpoch(){ now on mcu
   //~ long gps_date = readGPSDate();
   //~ int gYear = gps_date%100;
   //~ int gMonth = (int)(((gps_date-gYear)%10000)/100.0);
   //~ int gDay = (int)(((gps_date - 100*gMonth - gYear)%1000000)/10000.0);
   //~ long gps_time = readGPSTime();
   //~ int gSec = gps_time%100;
   //~ int gMin = (int)(((gps_time-gSec)%10000)/100.0);
   //~ int gHr = (int)(((gps_time - 100*gMin - gSec)%1000000)/10000.0);
   //~ struct tm tm;
   //~ tm.tm_year = gYear+100;
   //~ tm.tm_mon = gMonth-1;
   //~ tm.tm_mday = gDay;
   //~ tm.tm_hour = gHr;
   //~ tm.tm_min = gMin;
   //~ tm.tm_sec = gSec;
   //~ return timegm(&tm);
//~ };
//~ struct tm getGPS_Date_Time(){ now on mcu
   //~ long gps_date = readGPSDate();
   //~ int gYear = gps_date%100;
   //~ int gMonth = (int)(((gps_date-gYear)%10000)/100.0);
   //~ int gDay = (int)(((gps_date - 100*gMonth - gYear)%1000000)/10000.0);
   //~ long gps_time = readGPSTime();
   //~ int gSec = gps_time%100;
   //~ int gMin = (int)(((gps_time-gSec)%10000)/100.0);
   //~ int gHr = (int)(((gps_time - 100*gMin - gSec)%1000000)/10000.0);
   //~ struct tm tm;
   //~ tm.tm_year = gYear+100;
   //~ tm.tm_mon = gMonth-1;
   //~ tm.tm_mday = gDay;
   //~ tm.tm_hour = gHr;
   //~ tm.tm_min = gMin;
   //~ tm.tm_sec = gSec;
   //~ return tm;
//~ };


//Navigation Functions
float yawComp(float yaw, float yaw_d){
	float correction1 = fmodf(yaw+360,360.0)-fmodf(yaw_d+360,360.0);
	float correction = yaw-yaw_d;
	if (fabsf(correction)>fabsf(correction1)){
		correction = correction1;
	}
	int fixed_int = (int)(saturate(3*correction,-45,45));
	moveServo(fixed_int);
	return (float)fixed_int;
};

float yawCompLowGain(float yaw, float yaw_d){
	float correction1 = fmodf(yaw+360,360.0)-fmodf(yaw_d+360,360.0);
	float correction = yaw-yaw_d;
	if (fabsf(correction)>fabsf(correction1)){
		correction = correction1;
	}
	int fixed_int = (int)(saturate(correction,-45,45));
	moveServo(fixed_int);
	return (float)fixed_int;
};

float yawCompFlap(float yaw, float yaw_d,float amp, float flapTime){
	float correction1 = fmodf(yaw+360,360.0)-fmodf(yaw_d+360,360.0);
	float correction = yaw-yaw_d;
	if (fabsf(correction)>fabsf(correction1)){
		correction = correction1;
	}
	int bias = (int)(saturate(3*correction,-45,45));
	oscillateServo(bias,amp,flapTime);
	return bias;
};

/************************************************************
 * Function:
 *		GetDistanceToTarget
 * Parameters
 *		None
 * Return
 *		None
 * Description
 *		Computes the distance between our location and the
 *		target's coordinates
 ***********************************************************/
float GPS_GetDistanceToTarget(float targetLatitude, float targetLongitude){
	float R =6371000.0;//radius of the Earth
	float lat1 = ToRadians(readLattitude());
	float lat2 = ToRadians(targetLatitude);
	float lon1 = ToRadians(readLongitude()); // negative sign for Western Hemisphere
	float lon2 = ToRadians(targetLongitude); // negative sign for Western Hemisphere
	float dLat = lat2 - lat1;
	float dLon = lon2 - lon1;
	
	// reference: http://www.movable-type.co.uk/scripts/latlong.html
	
	// compute distance from target				
	float a = sin(dLat/2) * sin(dLat/2) + cos(lat1)*cos(lat2)*sin(dLon/2)*sin(dLon/2);
	float c = 2*atan2(sqrt(a),sqrt(1-a));
	float dGPSDist = R*c;

	return dGPSDist;
};

/************************************************************
 * Function:
 *		GPS_GetBearingToTarget
 * Parameters
 *		None
 * Return
 *		None
 * Description
 *		Computes the distance between our location and the
 *		target's coordinates
 ***********************************************************/
float GPS_GetBearingToTarget(float targetLatitude, float targetLongitude){
	float lat1 = ToRadians(readLattitude());
	float lat2 = ToRadians(targetLatitude);
	float lon1 = ToRadians(readLongitude()); // negative sign for Western Hemisphere
	float lon2 = ToRadians(targetLongitude); // negative sign for Western Hemisphere
	float dLat = lat2 - lat1;
	float dLon = lon2 - lon1;
	
	// reference: http://www.movable-type.co.uk/scripts/latlong.html
	
	// compute target bearing (angle from north)
	float y = sin(dLon)*cos(lat2);
	float x = cos(lat1)*sin(lat2)-sin(lat1)*cos(lat2)*cos(dLat);
	float dGPSBearing = ToDegrees(atan2(y,x));

	return dGPSBearing;
};



// IMU Functions
float readYaw(){
	return readFloatVar(mainMCU, IMU_YAW_READ);
};
float readPitch(){
	return readFloatVar(mainMCU, IMU_PITCH_READ);
};
float readRoll(){
	return readFloatVar(mainMCU, IMU_ROLL_READ);
};
float readYawRate(){
	return readFloatVar(mainMCU, IMU_YAW_RATE_READ);
};
float readPitchRate(){
	return readFloatVar(mainMCU, IMU_PITCH_RATE_READ);
};
float readRollRate(){
	return readFloatVar(mainMCU, IMU_ROLL_RATE_READ);
};
float readAccelX(){
	return readFloatVar(mainMCU, IMU_ACCEL_X_READ);
};
float readAccelY(){
	return readFloatVar(mainMCU, IMU_ACCEL_Y_READ);
};
float readAccelZ(){
	return readFloatVar(mainMCU, IMU_ACCEL_Z_READ);
};
float readIMUPressure(){
	return readFloatVar(mainMCU, IMU_PRESSURE_READ);
};
float readIMUTemperature(){
	return readFloatVar(mainMCU, IMU_Temperature_READ);
};
void TareIMU(){
	_move('I',"Tare");
};
void SaveIMU(){
	_move('I',"Save");
};
void SetHeadingIMU(int mode){
	char send[10];
	sprintf(send,"%d",mode);
	_move(IMU_HEADING_MODE,send);
};
//Actuator Functions
    //Mass Reads
float readMassPos(){
	return readFloatVar(mainMCU, MASS_READ)*massActLen;
};
float readMassVoltage(){
	return readFloatVar(mainMCU, MASS_READ)*MAX_ANALOG_VOLATAGE;
};
float readMassPercentage(){
	return readFloatVar(mainMCU, MASS_READ);
};
    // Mass Actuation
void moveMass(double percentage){
	char send[10];
	sprintf(send,"%.2f",percentage);
	_move('M',send);
};
void stopMass(){
	_move('M',"S");
};

    // Pump Reads
float readPumpPos(){
	float p = readFloatVar(mainMCU, PUMP_READ);
	return p/MAX_ANALOG_VOLATAGE*pumpActLen;
};
float readPumpVoltage(){
	return readFloatVar(mainMCU, PUMP_READ)/100*MAX_ANALOG_VOLATAGE;
};
float readPumpPercentage(){
	return readFloatVar(mainMCU, PUMP_READ);
};

     // Pump actuation
void movePump(double percentage){
	char send[10];
	sprintf(send,"%.2f",percentage);
	_move('P',send);
};
void stopPump(){
	_move('P',"S");
};
	//proppeler
void setPropellerSpeed(int speed){
	char send[10];
	sprintf(send,"%d",speed);
	_move('T',send);
};

void stopProppeller(){
	_move('T',"1");
};
    //Servo read
float readServoAngle(){
	return readFloatVar(mainMCU, SERVO_READ);
};
   //Servo actuation
void moveServo(int fixed_int){
	char pos[5];
	sprintf(pos,"%d",fixed_int);
	_move('S',pos);
};
void stopServo(){
	_move('S',"S");
};

void oscillateServo(double bias, double amp, float time_float){
	char msg[40]={0};
	sprintf(msg,"OSBA,%.3f,%.3f,%.3f\n",bias,amp,time_float);
	send(sock,msg,strlen(msg),0);
};

void oscillateServo2(int high_int, int low_int, float time_float){
	char msg[40]={0};
	sprintf(msg,"OSC,%d,%d,%.3f\n",high_int,low_int,time_float);
	send(sock,msg,strlen(msg),0);
};


// enviornmental sensors
   // Dissolved Oxygen
float readDOCON(){
	return readFloatVar(eSensorMCU, DO_CONC_READ);
};
float readDOTEMP(){
	return readFloatVar(eSensorMCU, DO_TEMP_READ);
};
float readDOPPS(){
	return readFloatVar(eSensorMCU, DO_PAR_PRESS_READ);
};
float readDOSAT(){
	return readFloatVar(eSensorMCU, DO_SAT_READ);
};


float readAlgaeCy(){
	return readFloatVar(eSensorMCU, CYC1_READ);
};
float readChlorophylCy(){
	return readFloatVar(eSensorMCU, CYC2_READ);
};
float readPar(){
	return readFloatVar(eSensorMCU, PAR_READ);
};

void readAcoustic(char* dataArray){
	int msgSize = 500;
	char s[50] = {0};
	sprintf(s,"R,%s,%d,-s\n",acousticMCU,ACOUSTIC_READ);
	send(sock,s,strlen(s),0);
	read(sock,dataArray,msgSize);
};

void syncAcousticDateTime(long dateTime){
	char s[50] = {0};
	sprintf(s,"R,%s,%d,%lu\n",acousticMCU,ACOUSTIC_SYNC_TIME,dateTime);
	printf("%s",s);
	send(sock,s,strlen(s),0);
};


#endif
