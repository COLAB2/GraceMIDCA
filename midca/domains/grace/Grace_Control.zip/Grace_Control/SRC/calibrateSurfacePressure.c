#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include "GliderFunIPC.h"

int main(int argc, char **argv){
	if (initIPC()<=0){
		printf("Could not connect to dataPipe.c\n");
		exit(-1);
	}
	int sampleNum = 0;
	if (argc > 1) sampleNum = atoi(argv[1]);
	else{sampleNum = 10;}
	if (sampleNum < 5)sampleNum = 5;
	logProgramStart(argc,argv);
	printf("%f\n",calibrateSurfacePressure(sampleNum));
}
