#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include <math.h>
#include <time.h>
#include "GliderFunIPC.h"

int parseWaypointsFile(char* fName, float* arr){
	return 0;
}

int main(int argc, char **argv){
	if (initIPC()<=0){
		printf("Could not connect to dataPipe.c\n");
		exit(-1);
	}
	logProgramStart(argc,argv);
	
	
	float longi = 0;
	float lat = 0; 
	float targetReached = 10;
	float wayPoints[100] = {0};
	int lonSet = 0;
	int latSet = 0;
	int waypointsSet = 0;
	float k = 10;
	float maxSpeed = 100;
	for (int i = 0;i<argc;i++){
			if(argv[i][0]=='-'){
				if(strcmp(argv[i]+1,"long")==0){
					longi = atof(argv[i+1]);
					lonSet = 1;
				}
				else if(strcmp(argv[i]+1,"lat")==0){
					lat = atof(argv[i+1]);
					latSet = 1;	
				}
				else if(strcmp(argv[i]+1,"targetReached")==0)
					targetReached = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"navFile")==0){
					int waypointsSet = parseWaypointsFile(argv[i+1],wayPoints);
				}
				else if(strcmp(argv[i]+1,"maxSpeed")==0)
					maxSpeed = atof(argv[i+1]);
				else if(strcmp(argv[i]+1,"k")==0)
					k = atof(argv[i+1]);
			}
	}
	float bearing = readYaw();
	float distance = 0;
	if (latSet==0 || lonSet==0 ){
		if(waypointsSet==0){
			printf("no destination set\n");
			system("python xbeeSender.py no destination set\n");
			exit(-1);
		}
	}
	if(readGPSValid()=='A'){
			bearing = GPS_GetBearingToTarget(lat,longi);
			distance = GPS_GetDistanceToTarget(lat,longi);
			printf("bearing = %f\n", bearing);
			printf("distance = %f\n", distance);
	}
	else{printf("GPS not available");}
	moveMass(saturate(_COM-30,0.01,_COM));
	movePump(99.9);
	time_t delay = time(NULL);
	time_t display = time(NULL);
	while(distance>targetReached){
        usleep(100000);
		//~ sleep(1);
		float angle = readYaw();
		if(readGPSValid()=='A' && distance>targetReached){
			bearing = GPS_GetBearingToTarget(lat,longi);
			distance = GPS_GetDistanceToTarget(lat,longi);
			if(difftime(time(NULL),delay)>=1){
				delay = time(NULL);
				setPropellerSpeed(saturate(k*distance,-maxSpeed,maxSpeed));
			}
			if(difftime(time(NULL),display)>=5){
				printf("bearing = %f\n", bearing);
				printf("distance = %f\n", distance);
				char tmpMsg[100] = {0};
				sprintf(tmpMsg,"python xbeeSender.py bearing=%f\n", bearing);
				system(tmpMsg);
				memset(tmpMsg,0,sizeof(tmpMsg));
				sprintf(tmpMsg,"python xbeeSender.py distance=%f\n", distance);
				system(tmpMsg);
				memset(tmpMsg,0,sizeof(tmpMsg));
				sprintf(tmpMsg,"python xbeeSender.py current angle=%f\n", angle);
				system(tmpMsg);
			}
		}
		else{setPropellerSpeed(0);}
		angle = readYaw();
		if(fabsf(angle-bearing)>1){
			//moveServo(saturate(angle-bearing,-45,45));
			float correction = yawCompLowGain(angle,bearing);
			char tmpMsg[100] = {0};
			sprintf(tmpMsg,"python xbeeSender.py moving servo to %f\n", correction);
			system(tmpMsg);
		}
	}
	moveServo(0);
	setPropellerSpeed(0);
	moveMass(_COM);
	system("python xbeeSender.py target reached\n");
}
