#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include "GliderFunIPC.h"
#include "GliderDefinitions.h"

int main(int argc, char **argv){
	if (initIPC()<0){
		printf("Could not connect to dataPipe.c\n");
		exit(-1);
	}
	logProgramStart(argc,argv);
	char check = 0;
	int src = 0;
	int flag = 0;
	for (int i = 0;i<argc;i++){
			if(argv[i][0]=='-'){
				if(strcmp(argv[i]+1,"source")==0){
					src = atoi(argv[i+1]);
					flag=1;
				}
				else if(strcmp(argv[i]+1,"val")==0){
					check = (char)atoi(argv[i+1]);
					flag=1;
				}
			}
	}
	if(flag==0){
		//OPTS
		printf("Source:\nMain mcu -> 0\nbattery monitor -> 1\nsensor mcu -> 2\nRaspberry Pi -> 3\nRefer to GliderDefinitions.h for val (values)");
		//END_OPTS
	}
	if(src==0){
			if(check==SERVO_READ ){
				printf("Servo angle = %f\n",readServoAngle());			
			}
			else if(check==MASS_READ){
				printf("Mass Percentage = %f\n",readMassPercentage());
			}
			else if(check==PUMP_READ) {
				printf("Pump Percentage = %f\n",readPumpPercentage()/pump_remap_constant);	
			}
			else if(check==PRESSURE_READ){
				printf("Pressure = %f\n",readPressure());		
			}
			else if(check==PRESSURE_AVG_READ){
				printf("Average Pressure = %f\n",readAveragedPressure());		
			}
			else if(check==PRESSURE_BWF_READ){
				printf("Filtered Pressure = %f\n",readFilteredPressure());
			}
			else if(check==GPS_TIME_READ){
				printf("Raw GPS Time = %lu\n",readGPSTime());	
			}
			else if(check==GPS_DATE_READ){
				printf("Date = %lu\n",readGPSDate());			
			}
			else if(check==GPS_LAT_READ){
				printf("Lattitude = %f\n",readLattitude());
			}
			else if(check==GPS_LONG_READ){
				printf("Longitude = %f\n",readLongitude());		
			}
			else if(check==GPS_NS_FLAG_READ){
				printf("NS Flag = %c\n",readLatFlag());			
			}
			else if(check==GPS_EW_FLAG_READ){
				printf("EW Flag = %c\n",readLongFlag());			
			}
			else if(check==GPS_VALID_READ){
				printf("GPSValid = %c\n",readGPSValid());			
			}
			else if(check==IMU_ROLL_READ){
				printf("Roll = %f\n",readRoll());	
			}
			else if(check==IMU_ROLL_RATE_READ){
				printf("Roll Rate = %f\n",readRollRate());		
			}
			else if(check==IMU_PITCH_READ){
				printf("Pitch = %f\n",readPitch());	
			}
			else if(check==IMU_PITCH_RATE_READ){
				printf("Pitch Rate = %f\n",readPitchRate());		
			}
			else if(check==IMU_YAW_READ){
				printf("Yaw = %f\n",readYaw());		
			}
			else if(check==IMU_YAW_RATE_READ){
				printf("Yaw Rate = %f\n",readYawRate());			
			}
			else if(check==IMU_ACCEL_X_READ){
				printf("X ACCEL = %f\n",readAccelX());		
			}
			else if(check==IMU_ACCEL_Y_READ){
				printf("Y ACCEL = %f\n",readAccelY());			
			}
			else if(check==IMU_ACCEL_Z_READ){
				printf("Z ACCEL = %f\n",readAccelZ());			
			}
			else if(check==IMU_Temperature_READ){
				printf("IMU TEMP = %f\n",readIMUTemperature());		
			}
			else if(check==IMU_PRESSURE_READ){
				printf("IMU PRESS = %f\n",readIMUPressure());			
			}
		}
		else if(src == 1){
			if(check==BATT_TEMP_READ){
				printf("InTemp = %d\n",readInTemp());				
			}
			else if(check==BATT_READ){
				printf("Battery = %f\n", readBattery());		
			}
		}
		else if(src == 2){
			if(check==DO_TEMP_READ){
				printf("DOTEMP = %f\n",readDOTEMP());			
			}
			else if(check==DO_CONC_READ){
				printf("DOCON = %f\n",readDOCON());	
			}
			else if(check==DO_SAT_READ ){
				printf("DOSAT = %f\n", readDOSAT());
			}
			else if(check==DO_PAR_PRESS_READ){
				printf("DOPPS = %f\n",readDOPPS());	
			}
			else if(check==CYC1_READ){
				printf("Algae = %f\n",readAlgaeCy());	
			}
			else if(check==CYC2_READ){
				printf("Chlorophyll = %f\n",readChlorophylCy());	
			}
			else if(check==PAR_READ){
				printf("Par = %f\n",readPar());					
			}
		}
		else if(src == 3){
			if ((int)check == SURFACE_PRESSURE){
				printf("Surface Pressure = %f\n",readSurfacePressure());
			}
			if ((int)check == 2){
				printf("Depth = %f\n",pressureToDepth(readFilteredPressure()));
			}
		}
	return 0;
}
