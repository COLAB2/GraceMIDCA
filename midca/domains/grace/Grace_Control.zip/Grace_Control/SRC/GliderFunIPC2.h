/*  GliderFunIPC.h
 *  This program has a function that sets up interprocess communication 
 *  to access the dataPipe.c program and functions that retieve data and 
 *  sends robot controls.
 * */
#pragma once
#ifndef _IPC_CONTROL
#define _IPC_CONTROL

#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <math.h>
#include "GliderDefinitions.h"

#define PI 3.14159

//Functions Declaratins
int initIPC();
void setSocketTimeout(float timeout);

void readGPS(float* dataArray);
float readLattitude();
float readLongitude();
long readGPSTime();
char readLatFlag();
char readLongFlag();
float GPS_GetDistanceToTarget(float targetLatitude, float targetLongitude);
float GPS_GetBearingToTarget(float targetLatitude, float targetLongitude);

void readIMU(float* dataArray);
float readYaw();
float readPitch();
float readRoll();
float readYawRate();
float readPitchRate();
float readRollRate();
float readAccelX();
float readAccelY();
float readAccelZ();
float readIMUPressure();
float readIMUTemperature();
void TareIMU();
void yawComp(float yaw, float yaw_d);

void readActuators(float* dataArray);
float readMassPos();
float readMassVoltage();
float readMassPercentage();
float readPumpPos();
float readPumpVoltage();
float readPumpPercentage();
float readServoAngle();

float readPressure();
float readAveragedPressure();
float readFilteredPressure();
float readSurfacePressure();
float pressureToDepth(float pressure);
float calibrateSurfacePressure(int samples); 
//float depthToPressure(float depth);									

void _move(char actuator, char *pos);
void movePump(double percentage);
void stopPump();
void moveMass(double percentage);
void stopMass();
void moveServo(int fixed_int);
void setPropeller(int speed);
void stopProppeller();					  
void stopServo();
void oscillateServo(double bias, double amp, float time_float);
void oscillateServo2(int high_int, int low_int, float time_float);

double readBattery();
int readInTemp();

float readDOCON();
float readDOTEMP();
float readDOPPS();
float readDOSAT();
float readPar();
float readPar2();
float readAlgaeCy();
float readChlorophylCy();
void readCyclops12(float* arr);

float readFloatVar(const char* mcu,char chartoSend);
long  readLongVar(const char* mcu,char chartoSend);
char  readCharVar(const char* mcu,char chartoSend);


#endif
