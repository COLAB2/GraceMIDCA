/*  GliderFun.h
 *  This program contains functions that talks to microcontroller for 
 *  robot control and data collection.
 * */
#pragma once
#ifndef _CONTROL
#define _CONTROL

#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h>  
#include <string.h>
#include <wiringPiI2C.h> 
#include "GliderDefinitions.h"


//variables
int mainMCU; 
int eSensorMCU;
int battMon;
int propMCU;
int acousticMCU;

//Functions Declaratins
void initMain(int hexId);
void initEnvSensors(int hexId);
void initAcousticReciever(int hexId);
void initPropeller(int hexId);
void initBattMon(int hexId);

void readGPS(float* dataArray);
float readLattitude();
float readLongitude();
long readGPSTime();
char readLatFlag();
char readLongFlag();

void readIMU(float* dataArray);
void TareIMU();
void SetHeadingIMU(int mode);
void SaveIMU();
float readYaw();
float readPitch();
float readRoll();
void yawComp(float yaw, float yaw_d);

void readActuators(float* dataArray);
float readMassPos();
float readMassVoltage();
float readMassPercentage();
float readPumpPos();
float readPumpVoltage();
float readPumpPercentage();
float readServoAngle();

float readPressure();
float readAveragedPressure();
float readFilteredPressure();

void setPropellerSpeed(int speed);
void movePump(double percentage);
void stopPump();
void moveMass(double percentage);
void stopMass();
void moveServo(int fixed_int);
void stopServo();
void oscillateServo(double bias, double amp, float time_float);
void oscillateServo2(int high_int, int low_int, float time_float);

double readBattery();
int readInTemp();

float readDOCON();
float readDOTEMP();
float readDOPPS();
float readDOSAT();
float readPar();
float readPar2();
float readAlgaeCy();
float readChlorophylCy();
void readCyclops12(float* arr);

void readAcoustic(char* dataArray);
void resetAcousticPin();

float readFloatVar(int mcu,char chartoSend);
long  readLongVar(int mcu,char chartoSend);
char  readCharVar(int mcu,char chartoSend);

//Functions Definitions


// setup i2c devices	
void initMain(int hexId){
	mainMCU = wiringPiI2CSetup(hexId); // wiringPiI2CSetup(0x32)
};

void initEnvSensors(int hexId){
	eSensorMCU = wiringPiI2CSetup(hexId); // wiringPiI2CSetup(0x39)
};

void initPropeller(int hexId){
	propMCU = wiringPiI2CSetup(hexId); // wiringPiI2CSetup(0x38)
};
void initAcousticReciever(int hexId){
	acousticMCU = wiringPiI2CSetup(hexId); // wiringPiI2CSetup(0x36)
};
void initBattMon(int hexId){
	battMon = wiringPiI2CSetup(hexId); // wiringPiI2CSetup(0x18)
};


//mcu read helper functions
float readFloatVar(int mcu, char charToSend){
	float data;
	write(mcu,(unsigned char*)&charToSend,1);
	usleep(waitTime);
	read(mcu,&data,READ_FLOAT); // READ DATA FROM MCU
	return data;
};
long readLongVar(int mcu, char charToSend){
	long data;
	write(mcu,(unsigned char*)&charToSend,1);
	usleep(waitTime);
	read(mcu,&data,READ_LONG);
	return data;
};
char readCharVar(int mcu, char charToSend){
	char data;
	write(mcu,(unsigned char*)&charToSend,1);
	usleep(waitTime);
	read(mcu,&data,READ_CHAR);
	return data;
};
//pressure sensor
float readPressure(){
	return readFloatVar(mainMCU, PRESSURE_READ);
};
float readAveragedPressure(){
	return readFloatVar(mainMCU, PRESSURE_AVG_READ);
};
float readFilteredPressure(){
	return readFloatVar(mainMCU, PRESSURE_BWF_READ);
};

// battey monitor chip functoions
double readBattery() {
	int readData, v;
	unsigned char vSourceH, vSourceL;
	double _battery_voltage;
	
	readData = wiringPiI2CReadReg16(battMon,0x58);
	vSourceH = readData & 0xFF;
	vSourceL = readData >> 8;
	
	v = ((int)(vSourceH << 4) + (int)(vSourceL >> 4));
	_battery_voltage = 23.988 * (double)v/4094.0;
	return _battery_voltage;
};

int readInTemp() {
	int readData,_internal_temperature;
	readData = wiringPiI2CReadReg8(battMon,0x38);
	_internal_temperature = (int)readData;
	return _internal_temperature;
};


//GPS Functions
void readGPS(float* dataArray) {
	float lattitude = readFloatVar(mainMCU, GPS_LAT_READ);
	float longitude= readFloatVar(mainMCU, GPS_LONG_READ);
    dataArray[0]=lattitude;
	dataArray[1]=longitude;
};
float readLattitude(){
	return readFloatVar(mainMCU, GPS_LAT_READ);
};
float readLongitude(){
	return readFloatVar(mainMCU, GPS_LONG_READ);
};
char readGPSValid(){
    char valid;
	char data = readCharVar(mainMCU, GPS_VALID_READ);
	valid = (data=='A' || data=='V')?data:'N';
	return valid;
};
char readLongFlag(){
   char valid;
   char data = readCharVar(mainMCU, GPS_EW_FLAG_READ);
   valid = (data=='E' || data=='W')?data:'X';
   return valid;
};
char readLatFlag(){
   char valid;
   char data = readCharVar(mainMCU, GPS_NS_FLAG_READ);
   valid = (data=='N' || data=='S')?data:'X';
   return valid;
};
long readGPSTime(){
	return readLongVar(mainMCU, GPS_TIME_READ);
};
long readGPSDate(){
	return readLongVar(mainMCU, GPS_DATE_READ);
};
//~ long getGPSEpoch(){
   //~ long gps_date = readGPSDate();
   //~ int gYear = gps_date%100;
   //~ int gMonth = (int)(((gps_date-gYear)%10000)/100.0);
   //~ int gDay = (int)(((gps_date - 100*gMonth - gYear)%1000000)/10000.0);
   //~ long gps_time = readGPSTime();
   //~ int gSec = gps_time%100;
   //~ int gMin = (int)(((gps_time-gSec)%10000)/100.0);
   //~ int gHr = (int)(((gps_time - 100*gMin - gSec)%1000000)/10000.0);
   //~ struct tm tm;
   //~ tm.tm_year = gYear+100;
   //~ tm.tm_mon = gMonth-1;
   //~ tm.tm_mday = gDay;
   //~ tm.tm_hour = gHr;
   //~ tm.tm_min = gMin;
   //~ tm.tm_sec = gSec;
   //~ return timegm(&tm);
//~ };
//~ struct tm getGPS_Date_Time(){
   //~ long gps_date = readGPSDate();
   //~ int gYear = gps_date%100;
   //~ int gMonth = (int)(((gps_date-gYear)%10000)/100.0);
   //~ int gDay = (int)(((gps_date - 100*gMonth - gYear)%1000000)/10000.0);
   //~ long gps_time = readGPSTime();
   //~ int gSec = gps_time%100;
   //~ int gMin = (int)(((gps_time-gSec)%10000)/100.0);
   //~ int gHr = (int)(((gps_time - 100*gMin - gSec)%1000000)/10000.0);
   //~ struct tm tm;
   //~ tm.tm_year = gYear+100;
   //~ tm.tm_mon = gMonth-1;
   //~ tm.tm_mday = gDay;
   //~ tm.tm_hour = gHr;
   //~ tm.tm_min = gMin;
   //~ tm.tm_sec = gSec;
   //~ return tm;
//~ };



// IMU Functions
float readYaw(){
	return readFloatVar(mainMCU, IMU_YAW_READ);
};
float readPitch(){
	return readFloatVar(mainMCU, IMU_PITCH_READ);
};
float readRoll(){
	return readFloatVar(mainMCU, IMU_ROLL_READ);
};
float readYawRate(){
	return readFloatVar(mainMCU, IMU_YAW_RATE_READ);
};
float readPitchRate(){
	return readFloatVar(mainMCU, IMU_PITCH_RATE_READ);
};
float readRollRate(){
	return readFloatVar(mainMCU, IMU_ROLL_RATE_READ);
};
float readAccelX(){
	return readFloatVar(mainMCU, IMU_ACCEL_X_READ);
};
float readAccelY(){
	return readFloatVar(mainMCU, IMU_ACCEL_Y_READ);
};
float readAccelZ(){
	return readFloatVar(mainMCU, IMU_ACCEL_Z_READ);
};
float readIMUPressure(){
	return readFloatVar(mainMCU, IMU_PRESSURE_READ);
};
float readIMUTemperature(){
	return readFloatVar(mainMCU, IMU_Temperature_READ);
};
void TareIMU(){
    write(mainMCU,(unsigned char*)&IMU_TARE,1);
};
void SaveIMU(){
	write(mainMCU,(unsigned char*)&IMU_SAVE,1);
}
void SetHeadingIMU(int mode){
	write(mainMCU,(unsigned char*)&IMU_HEADING_MODE,1);
	write(mainMCU,(unsigned char*)&mode,1);
}
void yawComp(float yaw, float yaw_d){
	float correction = (yaw-yaw_d);
	int fixed_int = (int)(saturate(correction,-45,45));
	moveServo(fixed_int);
};

//Actuator Functions
    //Mass Reads
float readMassPos(){
	float m = readFloatVar(mainMCU, MASS_READ);
	return m/MAX_ANALOG_VOLATAGE*massActLen;
};
float readMassVoltage(){
	return readFloatVar(mainMCU, MASS_READ);
};
float readMassPercentage(){
	float m = readFloatVar(mainMCU, MASS_READ);
	return m/MAX_ANALOG_VOLATAGE*100;
};
    // Mass Actuation
void moveMass(double percentage){
	char send = 'M';
	float f = percentage/100.0;
	if( (percentage >= 0.0) && (percentage <= 100.0) ){
		write(mainMCU,&send,1); // MUST CONVERT FLOAT TO CHARACTER TO SEND OVER I2C and CONVERT BACK ON OTHER SIDE
		char voltage = (char)(f*255); 
		write(mainMCU,(unsigned char*)&voltage,1);
	}
};
void stopMass(){
	write(mainMCU,&STOP_MASS,1);
};

    // Pump Reads
float readPumpPos(){
	float p = readFloatVar(mainMCU, PUMP_READ);
	return p/MAX_ANALOG_VOLATAGE*pumpActLen;
};
float readPumpVoltage(){
	return readFloatVar(mainMCU, PUMP_READ);
};
float readPumpPercentage(){
	float p = readFloatVar(mainMCU, PUMP_READ);
	return p/MAX_ANALOG_VOLATAGE*100;
};

     // Pump actuation
void movePump(double percentage){
	char send = 'P';
	float f = percentage/100.0*pump_remap_constant;
	if( (percentage > 0.0) && (percentage <= 100.0) ){
		write(mainMCU,&send,1);
		char voltage = (char)(f*255); 
		write(mainMCU,(unsigned char*)&voltage,1);
	}
};
void stopPump(){
	write(mainMCU,&STOP_PUMP,1);
};

    // propeller
void setPropellerSpeed(int speed){
	char send = 'S';
	//if( (speed >= -100) && (speed<= 100) ){
	if( (speed >= -100) && (speed<= 100) ){
		write(propMCU,&send,1);
		char spd = (char)speed; 
		write(propMCU,(unsigned char*)&spd,1);
	}
};
    //Servo read
float readServoAngle(){
	return readFloatVar(mainMCU, SERVO_READ);
};
   //Servo actuation
void moveServo(int fixed_int){
	char send = 'S';
	char fixed_angle;
	if( (fixed_int >= SERVO_MIN_ANGLE) && (fixed_int <= SERVO_MAX_ANGLE) ) {
		write(mainMCU,&send, 1);
		send = 'F';
		write(mainMCU,&send,1); 
		fixed_angle = (char)fixed_int;
		if( fixed_int <= -10 ) usleep(10000);//delay(10);
		write(mainMCU,&fixed_angle,1);
	}
};
void stopServo(){
	write(mainMCU,&STOP_SERVO,1);
};

void oscillateServo(double bias, double amp, float time_float){
	int min_ang = SERVO_MIN_ANGLE;
	int max_ang = SERVO_MAX_ANGLE;
	int val = (int)(bias+amp);
	int high_int = ((val>max_ang)?max_ang:val);// min 
	val = (int)(bias-amp);
	int low_int = ((val>max_ang)?val:min_ang); //max
	oscillateServo2(high_int,low_int,time_float);
};

void oscillateServo2(int high_int, int low_int, float time_float){
	char time;
	char high_angle;
	char low_angle;
	char send = 'S';
	// give it a high angle, low angle, and time interval
	if( (high_int >= SERVO_MIN_ANGLE && high_int <= SERVO_MAX_ANGLE) && (low_int >= SERVO_MIN_ANGLE && low_int <= SERVO_MAX_ANGLE) )
	{
		write(mainMCU, &send, 1);
		send = 'O';
		write(mainMCU,&send, 1);
		high_angle = (char)high_int;
		write(mainMCU,(unsigned char*)&high_angle,1);
		low_angle = (char)low_int;
		write(mainMCU, (unsigned char*)&low_angle,1);
		time = (char)(time_float*10);
		write(mainMCU, (unsigned char*)&time,1);
	}
};


// enviornmental sensors
   // Dissolved Oxygen
float readDOCON(){
	return readFloatVar(eSensorMCU, DO_CONC_READ);
};
float readDOTEMP(){
	return readFloatVar(eSensorMCU, DO_TEMP_READ);
};
float readDOPPS(){
	return readFloatVar(eSensorMCU, DO_PAR_PRESS_READ);
};
float readDOSAT(){
	return readFloatVar(eSensorMCU, DO_SAT_READ);
};


float readAlgaeCy(){
	return ((int)readCharVar(eSensorMCU, CYC1_READ))/255.0*MAX_ANALOG_VOLATAGE;
};
float readChlorophylCy(){
	return ((int)readCharVar(eSensorMCU, CYC2_READ))/255.0*MAX_ANALOG_VOLATAGE;
};
float readPar(){
	return ((int)readCharVar(eSensorMCU, PAR_READ))/255.0*MAX_ANALOG_VOLATAGE;
};

void readAcoustic(char* dataArray){
	int msgSize = 80;
	write(acousticMCU,(unsigned char*)&ACOUSTIC_READ,1);
	usleep(waitTime);
	read(acousticMCU,dataArray,msgSize);
};

void resetAcousticPin(){
	char data;
	char charToSend = 'E';
	write(acousticMCU,(unsigned char*)&charToSend,1);
};

void syncAcousticDateTime(long dateTime){
	write(acousticMCU,(unsigned char*)&ACOUSTIC_SYNC_TIME,1);
	write(acousticMCU,(unsigned char*)&dateTime,4);
};











// legacy functions
void readCyclops12(float* arr){
	//Cyclops 1 and 2
	char data[2];
	char send = 'C'; 
	write(eSensorMCU,(unsigned char*)&send,1);
	usleep(waitTime);
	read(eSensorMCU,&data,2); // READ DATA FROM MCU
	
	float c1 = (float)data[0]*MAX_ANALOG_VOLATAGE/255; 
	//m = m/MAX_ANALOG_VOLATAGE*mass_cm;
	float c2 =(int)data[1]*MAX_ANALOG_VOLATAGE/255; 
	arr[1]=c1;
	arr[2]=c2;
};

float readPar2(){
	char data;
	char send = 'P'; 
	write(eSensorMCU,(unsigned char*)&send,1);
	usleep(waitTime);
	read(eSensorMCU,&data,1); // READ DATA FROM MCU
	float p = (float)data*MAX_ANALOG_VOLATAGE/255; 
	return p;
};

void readIMU(float* dataArray) {
	int len = 26;
	char vnymr[len];
	char vdata[26];
	char rollString[10];
	char pitchString[10];
	char yawString[10];

	//char data2[3];
	char send = 'I';
	write(mainMCU,(unsigned char*)&send,1);
	usleep(waitTime);
	read(mainMCU,&vdata,26); // READ DATA FROM MCU
	strncpy(vnymr,vdata,len);
	int count = 0;
	int place = 0;
	for (int i = 0; i<len;i++){
		if (vnymr[i] == ',') {
			count++;
			place = 0;
			continue;
		}
		if (vnymr[i] == '+'){continue;}
		if (count == 0) {
			rollString[place] = vnymr[i];
			place++;
		}
		if (count == 1) {
			pitchString[place] = vnymr[i];
			place++;
		}
		if (count == 2) {
			yawString[place] = vnymr[i];
			place++;
		}
		dataArray[0] = atof(rollString);
		dataArray[1] = atof(pitchString);
		dataArray[2] = atof(yawString);
	}	
};

void readActuators(float* dataArray){
	char data[3];
	//const float mass_cm = 13.5; // DEPENDS ON ACTUATORS
	//const float pump_cm = 10.0; // DEPENDS ON ACTUATORS
	char send = 'A';
	
	// SEND EXCALAMATION POINT TO ACTUATORS MCU TWICE TO TRIGGER A DATA PULL
	write(mainMCU,(unsigned char*)&send,1);
	usleep(waitTime);
	read(mainMCU,&data,9); // READ DATA FROM MCU
	
	float m,p,s;
	memcpy(&p,&data,sizeof(m));
	memcpy(&m,&data[4],sizeof(p));
	s=(int)data[8]*MAX_ANALOG_VOLATAGE/255; // SERVO POSITION
	
	//printf("%f%,%f%,%f%\n",m,p,s);
	dataArray[0]=m/MAX_ANALOG_VOLATAGE*100.0;
	dataArray[1]=p/MAX_ANALOG_VOLATAGE*100.0;
	dataArray[2]=s*100.0;
}; 

#endif
