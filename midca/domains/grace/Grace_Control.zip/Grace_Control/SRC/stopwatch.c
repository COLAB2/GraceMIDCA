#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <sys/time.h>
#include <string.h>

#define clear() printf("\033[H\033[J");

int main(){
	struct timeval stop, start;
	gettimeofday(&start, NULL);
	//time_t start = time(NULL);
	while(1){
		gettimeofday(&stop, NULL);
		//clear();
        //printf("%f\n",difftime(time(NULL),start));
        printf("%f\n",(float)(stop.tv_sec - start.tv_sec)+(float)(stop.tv_usec - start.tv_usec)/1e6f);
	}
	
}
