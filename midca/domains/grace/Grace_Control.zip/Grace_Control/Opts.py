#!/usr/bin/env python

import os.path
import sys
def extractOpts(fname):
    cmds = []
    vars = []
    vartype =[]
    table = ""
    accum = False
    accum2 = False
    lastLineCMD=False
    f = open(filename, 'r')
    for line in f:
        if lastLineCMD:
            lastLineCMD=False
            idx = line.find("=",0,len(line))
            vars.append(line[:idx].strip())
            if "atof" in line:
                vartype.append("float")
            elif "atoi" in line:
                vartype.append("int")
            else:
                vartype.append("unknown ")
        if "if(strcmp(argv[i]+1" in line:
            temp = line.strip("\"").split(",")[-1]
            idx = temp.find(")==",0,len(temp))
            cmds.append(temp[:idx].strip(" "))
            lastLineCMD = True
	if "//END_OPTS" in line:
            accum =False
            accum2 = False
        if accum:
            temp = line.strip().replace('\"','').replace('printf(','').replace(');','').replace('\\n','\n')#.replace('\\t','').replace('\\n','\n')
	    temp = temp.strip().split('\\t')
            table = table+''.join(['%s\r\t']*len(temp)) % tuple(temp)
            #table = table+temp+"\r\n"
        if accum2:
            table = table+line+"\r"
        if "//OPTS" in line:
            accum=True
            if "//OPTS_NO_FORMAT" in line:
                 accum =False
                 accum2 = True
    table =table+"\r\n"+filename+" command line args\r\n"
    table = table+'{:<25}  {:<15}  {:<8}\r\n'.format("|commands","|var","|type")
    table = table+ '-'*55+"\r\n"
    for i in range(len(cmds)):
        table = table+ '{:<25}  {:<15}  {:<8}\r\n'.format(cmds[i],vars[i],vartype[i])
    return table

filename = "SRC/"
#subprocess.check_output("python commandLineHelper.py autoBalance.c",shell=True) 
filename = filename+sys.argv[1]
if not os.path.isfile(filename):
    filename=filename+".c"
    if not os.path.isfile(filename):
	    print 'File does not exist.'
    else:
        print extractOpts(filename)
else:
    print extractOpts(filename)
        

    
