systemctl stop wpa_supplicant.service
wpa_cli terminate >/dev/null 2>&1
rm -r /var/run/wpa_supplicant >/dev/null 2>&1
wpa_supplicant -B -i "$wifidev" -c $1

sudo ifconfig wlan0 down

sudo ifconfig wlan0 up
      