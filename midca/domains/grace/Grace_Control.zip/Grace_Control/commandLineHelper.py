#!/usr/bin/env python

import os.path
import sys


filename = "SRC/"
#subprocess.check_output("python commandLineHelper.py autoBalance.c",shell=True) 
filename = filename+sys.argv[1]
if not os.path.isfile(filename):
    print 'File does not exist.'
else:
    cmds = []
    vars = []
    vartype =[]
    lastLineCMD=False
    f = open(filename, 'r')
    for line in f:
        if lastLineCMD:
            lastLineCMD=False
            idx = line.find("=",0,len(line))
            vars.append(line[:idx].strip())
            if "atof" in line:
                vartype.append("float")
            elif "atoi" in line:
                vartype.append("int")
            else:
                vartype.append("unknown ")
        if "if(strcmp(argv[i]+1" in line:
            temp = line.strip("\"").split(",")[-1]
            idx = temp.find(")==",0,len(temp))
            cmds.append(temp[:idx].strip(" "))
            lastLineCMD = True
        

    print filename," command line args"
    print '{:<25}  {:<15}  {:<8}'.format("|commands","|var","|type")
    print '-'*55
    for i in range(len(cmds)):
        print '{:<25}  {:<15}  {:<8}'.format(cmds[i],vars[i],vartype[i])
