import socket
import sys
server_address = 'GoPro'
sock =socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)

    #sock.bind((host,port))
sock.settimeout(5)
sock.connect("\0"+server_address)
    
num = int(sys.argv[1])
if num == 0:
	sock.sendall('Stop')
	print 'Stop'
if num == 1:
	sock.sendall('Video')
	print 'Video'
if num == 2:
	sock.sendall('stream,DATALOG/pooltest')
	print 'stream,pooltest'
	num = 5
if num == 4:
	sock.sendall('DownloadLast')
	print sock.recv(1024)
if num == 5:
	sock.sendall('Kill')
	print sock.recv(1024)
sock.close()
