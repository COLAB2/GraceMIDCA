import socket
from goprocam import GoProCamera,constants
import time

video = constants.Mode.VideoMode
multishot = constants.Mode.MultiShotMode
timelapse = constants.Mode.SubMode.MultiShot.TimeLapse
capture = 0
custom_name=""
count = 0

server_address = 'GoPro'
#print(type(gpc))
#gpc.overview()
def setupServer():
    sock =socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
    try:
        #sock.bind((host,port))
        sock.bind("\0"+server_address)
        #sock.setblocking(False)
    except socket.error as msg:
        print(msg)
        return None
    print("Bind complete.")
    return sock

def setupConnection(s):
    s.listen(1) #only one connection at a time
    conn,address = s.accept() #accepts connection from client and returns a socket for data transmission and clients address
    #print(type(conn),type(address))
    print("Connected to: "+address.decode('utf-8'))
    return conn


def Repeat(message):
    print(message)
    if len(message) > 1:
        return message[1]
    else:
        return " "

def dataTransfer(conn,gpc):
    global capture
    global custom_name
    global count
    print("Connection open")
    timer = 5
    while True:
        print("loop")
        try:
            data = conn.recv(1024)
            data = data.decode('utf-8')
        except:
            data = ""
        print(data)
        dataMessage = data.split(',',1)#command is first element of the resulting array
        command = dataMessage[0]
        print(dataMessage)
        if command == 'reconnect':
            gpc = GoProCamera.GoPro()
        elif command == 'stream':#command -> stream,sequence_name,delay(optional)
            capture = 1
            conn.setblocking(False)
            custom_name=dataMessage[1]
            timer = 10
            if len(dataMessage) > 2:
                timer=float(dataMessage[2])
            conn.sendall(str.encode(custom_name))
        elif command == 'Stop':
            if capture == 0:
                gpc.shutter(constants.stop)
            capture = 0
            conn.setblocking(True)
            conn.sendall(str.encode(str(count)))
            count=0
            custom_name=""
        elif command == 'DownloadLast':
            gpc.downloadLastMedia() #returns path to file downloaded from gpc
            #print(gpc.getMedia())
            conn.sendall(str.encode(gpc.getMedia()))
        elif command == 'Download':
            if len(dataMessage)<1:
                gpc.downloadLastMedia(dataMessage[1]) #returns path to file downloaded from gpc
                conn.sendall(str.encode(dataMessage[1]))
        elif command == 'Video':
            gpc.shoot_video()
            conn.sendall("starting video")
        elif command == 'Kill':
            print("closing connection")
            conn.close()
            break
        else:
            if capture == 0:
                print("unknown command: "+command )
                conn.sendall(str.encode("unknown"))
        if capture == 1:
            gpc.downloadLastMedia(gpc.take_photo(0.1),custom_name+str(count))
            count+=1


go= GoProCamera.GoPro()
s = setupServer()
#print(s.fileno())
#print(s.getsockname())
while True:
    if s == None:
        break
    if capture == 1:
        go.downloadLastMedia(go.take_photo(0.1),custom_name+str(count))
        count+=1
        s.settimeout(2)
    try:
        conn = setupConnection(s)
        dataTransfer(conn,go)
    except Exception as msg:
        print(msg)
        s.close()
        s = setupServer()
        
        
