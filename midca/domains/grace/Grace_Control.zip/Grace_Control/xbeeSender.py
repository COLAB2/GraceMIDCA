import serial
import sys

msg = ""
for i in range(len(sys.argv)-1):
    msg+=sys.argv[i+1]+' '
      
x= serial.Serial(port="/dev/ttyS0",baudrate=9600,parity=serial.PARITY_NONE,stopbits=serial.STOPBITS_ONE,bytesize=serial.EIGHTBITS)
x.write(msg+'\r\n')
print msg