import serial
import time
from subprocess import call, Popen,check_output
import os
import sys


#put continously running progam names in this array
continuous = ["logger","dataPipe","GoProServer.py","depthDive","depthDive","PIDDepthDive","PID2depthDive","videos.py","pictures.py","navScript","navThrusterScript","autoBalance","autoBuoyancy"]
x= serial.Serial(port="/dev/ttyS0",baudrate=9600,parity=serial.PARITY_NONE,stopbits=serial.STOPBITS_ONE,bytesize=serial.EIGHTBITS)
# get pid of a process with name
# ps -A | grep loggerAllIPC

path = "/home/pi/Desktop/Grace_Control/"
os.chdir(path)
os.system("./dataPipe &")
#call(['./Actuators','P', '99.9'],cwd=path)
#call(['./Actuators','M', '50.0'],cwd=path)
time.sleep(30)
x.write("\n\nGrace 2.5 Yellow Ready\r\n")
guiGoAheadResponse = "$%GO%$"
while 1:
    msg = x.readline()
    x.write(msg)
    msg=msg.strip("\n").strip("\r")
    print msg
    if msg.strip("\n").strip("\r") == "exit()":
        print "leaving"
        break
    if msg.strip("\n").strip("\r") == guiGoAheadResponse:
        f = open(path+"Next_Dive_GO",'w')
        f.write("1")
        f.close()
        continue
    try:
        #cmdlist = msg.split(",")
        #call(cmdlist,cwd=path)
        cont = False
        temp = msg.split()[0]
        if temp=="python" or temp=="python3":
	    temp = msg.split()[1]
	print temp
        for i in range(len(continuous)):
	    if continuous[i] in temp:
                cont = True
                break    
        if not cont:
            out = check_output(msg,shell=True,cwd=path) 
            #p = Popen(msg,shell=True,cwd=path)
            print out
            x.write(out+ "\r\n")
        else:
            p = Popen(msg,shell=True,cwd=path)
            print str(p.pid+1)
            x.write("PID = " + str(p.pid+1) + "\r\n")
    except:
        print "unexpected error:", sys.exc_info()[0]
        #x.write(sys.exc_info()[0])
        continue
